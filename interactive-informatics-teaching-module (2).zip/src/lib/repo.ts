import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import {
  lkpdSubmissions,
  moduleContent,
  quizResults,
  studentComments,
} from "@/db/schema";
import { DEFAULT_CONTENT } from "./content";
import type {
  LkpdTask,
  ModuleContent,
  ModuleMeta,
  QuizQuestion,
  Section,
  Slide,
} from "./types";

const KEYS = ["meta", "sections", "slides", "lkpd", "quiz"] as const;
type ContentKey = (typeof KEYS)[number];

let seeded = false;

export async function ensureSeeded() {
  if (seeded) return;
  await db
    .insert(moduleContent)
    .values([
      { key: "meta", value: DEFAULT_CONTENT.meta },
      { key: "sections", value: DEFAULT_CONTENT.sections },
      { key: "slides", value: DEFAULT_CONTENT.slides },
      { key: "lkpd", value: DEFAULT_CONTENT.lkpd },
      { key: "quiz", value: DEFAULT_CONTENT.quiz },
    ])
    .onConflictDoNothing();
  seeded = true;
}

function arr<T>(value: unknown, fallback: T[]): T[] {
  return Array.isArray(value) && value.length > 0 ? (value as T[]) : fallback;
}

export async function getContent(): Promise<ModuleContent> {
  await ensureSeeded();
  const rows = await db.select().from(moduleContent);
  const map = new Map<string, unknown>(rows.map((r) => [r.key, r.value]));

  const lkpdRaw = map.get("lkpd") as ModuleContent["lkpd"] | undefined;
  const quizRaw = map.get("quiz") as ModuleContent["quiz"] | undefined;

  return {
    meta: { ...DEFAULT_CONTENT.meta, ...((map.get("meta") as Partial<ModuleMeta>) ?? {}) },
    sections: arr<Section>(map.get("sections"), DEFAULT_CONTENT.sections),
    slides: arr<Slide>(map.get("slides"), DEFAULT_CONTENT.slides),
    lkpd: {
      intro: lkpdRaw?.intro ?? DEFAULT_CONTENT.lkpd.intro,
      tasks: arr<LkpdTask>(lkpdRaw?.tasks, DEFAULT_CONTENT.lkpd.tasks),
    },
    quiz: {
      intro: quizRaw?.intro ?? DEFAULT_CONTENT.quiz.intro,
      questions: arr<QuizQuestion>(quizRaw?.questions, DEFAULT_CONTENT.quiz.questions),
    },
  };
}

export async function saveContent(key: ContentKey, value: unknown) {
  await ensureSeeded();
  await db
    .insert(moduleContent)
    .values({ key, value })
    .onConflictDoUpdate({
      target: moduleContent.key,
      set: { value, updatedAt: new Date() },
    });
}

export function shuffle<T>(list: T[]): T[] {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

export type PublicQuestion = {
  id: string;
  topic: string;
  question: string;
  options: string[];
};

/** 20 soal acak dari bank 25 soal, pilihan jawaban juga diacak. Kunci jawaban tidak dikirim. */
export async function getExamSet(): Promise<PublicQuestion[]> {
  const content = await getContent();
  return shuffle(content.quiz.questions).slice(0, 20).map((q) => ({
    id: q.id,
    topic: q.topic,
    question: q.question,
    options: shuffle(q.options),
  }));
}

export type QuizAnswerRow = { id: string; picked: string };

export async function gradeQuiz(rows: QuizAnswerRow[]) {
  const content = await getContent();
  const byId = new Map(content.quiz.questions.map((q) => [q.id, q]));
  const detail = rows.map((row) => {
    const q = byId.get(row.id);
    const correctText = q ? q.options[q.answer] : "";
    const correct = Boolean(q) && row.picked === correctText;
    return {
      id: row.id,
      question: q?.question ?? "",
      picked: row.picked,
      correctText,
      correct,
    };
  });
  const correct = detail.filter((d) => d.correct).length;
  const total = Math.max(rows.length, 20);
  const score = Math.round((correct / total) * 100);
  return { correct, total, score, detail };
}

export async function saveQuizResult(input: {
  studentName: string;
  className: string;
  score: number;
  correct: number;
  total: number;
  answers: unknown;
}) {
  const [row] = await db.insert(quizResults).values(input).returning();
  return row;
}

export async function saveLkpd(input: {
  studentName: string;
  className: string;
  answers: unknown;
}) {
  const [row] = await db.insert(lkpdSubmissions).values(input).returning();
  return row;
}

export async function saveComment(input: {
  studentName: string;
  className: string;
  message: string;
}) {
  const [row] = await db.insert(studentComments).values(input).returning();
  return row;
}

export async function listQuizResults() {
  return db.select().from(quizResults).orderBy(desc(quizResults.createdAt));
}

export async function listLkpd() {
  return db.select().from(lkpdSubmissions).orderBy(desc(lkpdSubmissions.createdAt));
}

export async function listComments() {
  return db.select().from(studentComments).orderBy(desc(studentComments.createdAt));
}
