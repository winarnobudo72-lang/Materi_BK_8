import type { ModuleContent } from "./types";

export const DEFAULT_CONTENT: ModuleContent = {
  meta: {
    school: "SMP NEGERI 2 NGADIREJO",
    phase: "Fase D / Kelas VIII",
    teacher: "Budi Winarno, S.Kom",
    subject: "Informatika",
    material: "Elemen Berpikir Komputasional",
    time: "4 × 40 menit (2 pertemuan)",
    title: "Elemen Berpikir Komputasional",
    subtitle:
      "Modul ajar interaktif: memahami himpunan data terstruktur dan menuliskan instruksi dengan pseudocode berkosakata terbatas.",
    capaian:
      "Peserta didik mampu memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari, memahami konsep lembar kerja pengolah data dan menerapkan berpikir komputasional dalam menyelesaikan persoalan yang mengandung himpunan data berstruktur sederhana dengan volume kecil, dan mendisposisikan berpikir komputasional yang diperlukan pada berbagai bidang; mampu menuliskan sekumpulan instruksi dengan menggunakan sekumpulan kosakata terbatas atau simbol dalam format pseudocode.",
    tujuan:
      "Peserta didik mampu memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari.",
    atp: "Memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari.",
    profilPelajar:
      "Bernalar kritis dan kreatif — peserta didik terbiasa memecahkan masalah nyata di sekitarnya secara runtut, memilih informasi yang penting, dan menyusun solusi langkah demi langkah.",
  },
  sections: [
    {
      id: "himpunan-data",
      no: "01",
      kicker: "Bab 01 · Konsep Dasar",
      title: "Himpunan Data Terstruktur dalam Kehidupan Sehari-hari",
      lead: "Setiap hari kita dikelilingi kumpulan data yang sudah tersusun rapi dalam baris dan kolom — sering tanpa kita sadari itu adalah himpunan data terstruktur.",
      body: [
        "Data adalah fakta mentah tentang sesuatu, misalnya nama, angka, tanggal, atau kejadian. Ketika data itu dikumpulkan lalu disusun menurut aturan yang jelas — ada judul kolom, ada baris, ada jenis isian — maka terbentuklah himpunan data terstruktur. Contoh paling dekat ada di kelas kita: daftar hadir, jadwal pelajaran, dan daftar nilai ulangan.",
        "Disebut terstruktur karena setiap bagian punya tempat tetap. Pada daftar nilai, kolom pertama selalu nomor absen, kolom kedua nama siswa, kolom berikutnya nilai. Karena tempatnya tetap, komputer dapat menghitung rata-rata, mencari nilai tertinggi, atau mengurutkan nama dengan cepat dan tanpa salah.",
        "Sebaliknya, data tidak terstruktur tidak punya aturan susunan: foto liburan, suara rekaman, atau coretan bebas di papan tulis. Komputer membutuhkan usaha jauh lebih besar untuk memahaminya. Karena itu, dalam Informatika kita mulai belajar dari data berstruktur sederhana dengan volume kecil: satu daftar, satu kelas, satu kegiatan.",
      ],
      points: [
        {
          label: "Baris (record)",
          text: "Satu objek utuh, misalnya satu siswa: “7 · Salsabila Putri · VIIIB · 88”.",
        },
        {
          label: "Kolom (field)",
          text: "Satu jenis informasi yang sama untuk semua baris, misalnya kolom “Nilai”.",
        },
        {
          label: "Judul kolom",
          text: "Keterangan isi kolom agar data dapat dipahami orang lain tanpa penjelasan tambahan.",
        },
        {
          label: "Volume kecil",
          text: "Jumlah baris yang masih muat diperiksa manual, misalnya 28 siswa satu kelas.",
        },
      ],
      image: "images/bab-data.jpg",
      imageCaption:
        "Daftar nilai, absensi, dan kartu perpustakaan: himpunan data terstruktur yang dipakai setiap hari.",
      caseTitle: "Contoh Kasus — Daftar Nilai Ulangan Harian",
      caseIntro:
        "Bu Rina mencatat hasil ulangan harian Informatika kelas VIIIB pada selembar kertas bergaris. Kertas itu punya judul kolom: No, Nama, Nilai, Ketuntasan. Setiap siswa mengisi tepat satu baris.",
      caseSteps: [
        "Baris ke-1 sampai ke-28 berisi data 28 siswa; tidak ada baris yang bolong atau dobel.",
        "Kolom “Nilai” hanya boleh diisi angka 0–100, sehingga mudah dijumlahkan.",
        "Dari himpunan itu Bu Rina menemukan nilai tertinggi 96, terendah 54, dan rata-rata kelas 78,6.",
        "Siswa yang nilainya < 75 ditandai pada kolom Ketuntasan untuk diberi remedial.",
      ],
      caseNote:
        "Coba amati: data mana di sekitarmu yang sudah punya baris dan kolom tetap? Tuliskan tiga contoh pada LKPD Aktivitas 1.",
    },
    {
      id: "dekomposisi",
      no: "02",
      kicker: "Bab 02 · Elemen Berpikir Komputasional",
      title: "Dekomposisi — Memecah Masalah Besar Menjadi Bagian Kecil",
      lead: "Tidak ada orang yang mengerjakan seluruh acara sekaligus dalam satu tarikan napas. Kita selalu memecahnya menjadi tugas-tugas kecil yang bisa dikerjakan satu per satu.",
      body: [
        "Dekomposisi adalah proses memecah masalah besar, informasi rumit, atau proses panjang menjadi bagian-bagian kecil yang lebih mudah dipahami dan dikerjakan. Komputer bekerja dengan cara yang sama: program besar dibagi menjadi prosedur kecil, dan setiap prosedur dikerjakan satu per satu.",
        "Manfaat dekomposisi terasa ketika sebuah tugas melibatkan banyak hal sekaligus. Mengadakan class meeting terdengar berat, tetapi setelah dipecah — perlengkapan, konsumsi, acara, dokumentasi — setiap bagiannya dapat diberikan kepada tim yang berbeda dan dikerjakan tanpa saling menunggu.",
        "Dalam mengolah data pun kita berdekomposisi: mengolah daftar nilai kelas dipecah menjadi mengumpulkan data, merapikan baris, menghitung, lalu menuliskan kesimpulan. Langkah kecil seperti ini yang nantinya kita tuliskan menjadi pseudocode.",
      ],
      points: [
        {
          label: "1. Kenali masalah",
          text: "Tuliskan satu kalimat: apa yang sebenarnya ingin diselesaikan?",
        },
        {
          label: "2. Pisahkan bagiannya",
          text: "Kelompokkan hal yang berkaitan menjadi sub-masalah berukuran kecil.",
        },
        {
          label: "3. Tentukan urutan",
          text: "Bagian mana dikerjakan lebih dulu, bagian mana boleh berjalan paralel.",
        },
        {
          label: "4. Periksa kembali",
          text: "Pastikan tidak ada bagian yang terlewat dan tidak ada pekerjaan ganda.",
        },
      ],
      image: "images/bab-dekomposisi.jpg",
      imageCaption:
        "Piket dan persiapan class meeting: satu masalah besar dipecah menjadi tugas kecil yang dikerjakan bergotong royong.",
      caseTitle: "Contoh Kasus — Persiapan Class Meeting Kelas VIII",
      caseIntro:
        "Kelas VIIIC ditunjuk mengisi stan bazar saat class meeting. Anggaran Rp300.000 dan waktu persiapan hanya dua hari. Kalau dikerjakan serabutan, pasti ada yang lupa.",
      caseSteps: [
        "Bagian A — Perlengkapan: daftar belanja, pinjam terpal dan meja ke kantin.",
        "Bagian B — Konsumsi: tentukan menu, hitung porsi 28 siswa + 3 guru.",
        "Bagian C — Acara: susun jadwal siapa jaga stan dari jam ke jam.",
        "Bagian D — Dokumentasi: siapkan poster sederhana dan kamera HP untuk laporan.",
        "Setiap bagian punya penanggung jawab sendiri, sehingga tugas selesai tanpa saling menunggu.",
      ],
      caseNote:
        "Dekomposisi membuat pekerjaan besar menjadi terlihat: mana yang sulit, mana yang mudah, dan mana yang bisa dikerjakan bersamaan.",
    },
    {
      id: "pola",
      no: "03",
      kicker: "Bab 03 · Elemen Berpikir Komputasional",
      title: "Pengenalan Pola — Menemukan Kesamaan dan Keteraturan",
      lead: "Setelah masalah dipecah, kita mencari hal yang berulang. Pola yang ditemukan membuat pekerjaan tidak perlu diulang dari nol.",
      body: [
        "Pengenalan pola adalah kemampuan melihat kesamaan, keteraturan, atau perulangan di antara potongan-potongan masalah. Dalam himpunan data terstruktur, pola muncul sebagai nilai yang berulang, aturan yang selalu sama, atau kecenderungan pada suatu kolom.",
        "Mengenali pola berarti kita dapat memakai solusi lama untuk masalah baru. Jika setiap hari Senin jadwal piket selalu berbentuk “nama penjaga, jam, tugas”, maka format yang sama dapat dipakai untuk jadwal jaga stan bazar tanpa mendesain ulang.",
        "Komputer sangat mengandalkan pola. Perulangan (loop) dalam program lahir dari pola, dan pencarian data juga bekerja karena data punya struktur yang konsisten. Tugas kita adalah melatih mata untuk melihatnya.",
      ],
      points: [
        {
          label: "Pola pada data",
          text: "Nilai yang sering muncul, urutan tanggal yang selalu naik, kode kelas VIIIA–VIIIG.",
        },
        {
          label: "Pola pada masalah",
          text: "Langkah yang sama untuk kelompok berbeda, misalnya cara menghitung porsi makanan.",
        },
        {
          label: "Pola pada perilaku",
          text: "Jam istirahat, jam pulang, dan jam piket selalu berulang setiap hari sekolah.",
        },
        {
          label: "Manfaatnya",
          text: "Rumus, template, dan perulangan: satu penyelesaian dipakai berkali-kali.",
        },
      ],
      image: "images/bab-pola.jpg",
      imageCaption:
        "Motif batik yang berulang dan deretan lapak pasar: pola yang sama membuat kita mudah menebak bagian berikutnya.",
      caseTitle: "Contoh Kasus — Antrian Warung Kantin",
      caseIntro:
        "Setiap jam istirahat, antrian warung kantin Bu Yem selalu berperilaku sama. Pak Deni mencatat 12 kali pengamatan pada satu minggu.",
      caseSteps: [
        "Jam 09.30–09.40 selalu ramai: 15–20 siswa mengantri (pola waktu ramai).",
        "Menu paling laris selalu es teh (Rp4.000) dan nasi goreng (Rp8.000) — pola preferensi.",
        "Siswa kelas VIII selalu membeli berkelompok 3–4 orang — pola jumlah.",
        "Karena polanya jelas, Bu Yem menyiapkan 20 porsi nasi goreng dan menambah satu loket pembayaran tepat jam 09.25.",
      ],
      caseNote:
        "Coba tuliskan satu pola yang kamu temukan pada daftar nilai kelas, misalnya nilai mana yang paling sering muncul.",
    },
    {
      id: "abstraksi",
      no: "04",
      kicker: "Bab 04 · Elemen Berpikir Komputasional",
      title: "Abstraksi — Mengambil yang Penting, Menyingkirkan yang Tidak",
      lead: "Peta tidak menggambarkan setiap batu dan setiap pohon. Ia hanya menampilkan yang kita butuhkan untuk sampai ke tujuan. Itulah abstraksi.",
      body: [
        "Abstraksi adalah proses menyaring informasi agar hanya hal-hal penting yang dipertahankan, sedangkan rincian yang tidak relevan disingkirkan. Abstraksi dipakai untuk menyederhanakan masalah supaya fokus pada tujuan.",
        "Saat membuat himpunan data terstruktur, kita selalu berabstraksi. Untuk keperluan perpustakaan, data siswa cukup berisi nomor kartu, nama, dan kelas — tinggi badan serta tanggal lahir tidak diperlukan, sehingga tidak ikut dicatat.",
        "Abstraksi juga dipakai saat menulis pseudocode. Kita cukup menulis “BACA data nilai”, tanpa menjelaskan bagaimana keyboard mengirim sinyal ke komputer. Detail itu memang sengaja ditinggalkan supaya langkah utama tetap terlihat jelas.",
      ],
      points: [
        {
          label: "Tetapkan tujuan",
          text: "Apa pertanyaan yang ingin dijawab dari data itu? Tujuan menentukan kolom yang perlu ada.",
        },
        {
          label: "Buang yang tidak perlu",
          text: "Rincian yang tidak memengaruhi penyelesaian masalah tidak dimasukkan.",
        },
        {
          label: "Kelompokkan yang serupa",
          text: "“Nama lengkap, panggilan, nama panggilan” cukup disatukan menjadi satu kolom Nama.",
        },
        {
          label: "Sembunyikan detail proses",
          text: "Pada pseudocode, satu baris perintah boleh mewakili banyak langkah teknis.",
        },
      ],
      image: "images/bab-abstraksi.jpg",
      imageCaption:
        "Peta rute rumah ke sekolah: hanya jalan, tikungan, dan tanda penting yang dipertahankan.",
      caseTitle: "Contoh Kasus — Peta Rute Rumah ke Sekolah",
      caseIntro:
        "Rani pindah dari Semarang ke Ngadirejo. Ia membuatkan peta sederhana untuk adiknya yang akan bersekolah di SMP Negeri 2 Ngadirejo.",
      caseSteps: [
        "Yang dipertahankan: rumah, dua persimpangan, jembatan, gerbang sekolah, dan perkiraan waktu.",
        "Yang disingkirkan: warung yang tutup, warna cat rumah, jumlah pohon, nama pemilik toko.",
        "Hasilnya satu lembar peta dengan 4 titik penting dan panah arah — mudah dibaca dalam 10 detik.",
        "Abstraksi yang sama dipakai untuk menyusun data perjalanan: Nama, Titik Awal, Titik Tujuan, Menit.",
      ],
      caseNote:
        "Abstraksi menentukan kolom sebuah himpunan data. Kolom yang terlalu banyak membuat data sulit dibaca; terlalu sedikit membuat data tidak dapat dipakai.",
    },
    {
      id: "algoritma",
      no: "05",
      kicker: "Bab 05 · Elemen Berpikir Komputasional",
      title: "Algoritma & Pseudocode Berkosakata Terbatas",
      lead: "Setelah masalah dipecah, pola ditemukan, dan detail disaring — tiba saatnya menyusun urutan langkah yang pasti. Komputer menuntut ketepatan, bukan kira-kira.",
      body: [
        "Algoritma adalah urutan langkah-langkah yang runtut dan berhenti untuk menyelesaikan sebuah masalah. Resep masakan, cara berangkat sekolah, dan prosedur peminjaman buku adalah algoritma yang dipakai setiap hari.",
        "Pseudocode adalah cara menuliskan algoritma memakai bahasa setengah manusia setengah program, dengan kosakata yang dibatasi. Karena kosakatanya terbatas, tulisan kita tidak bermakna ganda dan mudah diterjemahkan menjadi program kelak.",
        "Kosakata yang kita gunakan pada modul ini hanyalah: MULAI, SELESAI, BACA, TULIS, HITUNG, JIKA … MAKA … SELAINYA …, ULANGI … SAMPAI …, dan SALIN. Cukup delapan kosakata untuk menyelesaikan persoalan himpunan data sederhana.",
      ],
      points: [
        {
          label: "MULAI / SELESAI",
          text: "Tanda awal dan akhir algoritma; setiap pseudocode wajib punya keduanya.",
        },
        {
          label: "BACA / TULIS",
          text: "Menerima masukan dari pengguna dan menampilkan keluaran.",
        },
        {
          label: "HITUNG",
          text: "Melakukan operasi: menjumlah, menghitung rata-rata, mencari nilai terbesar.",
        },
        {
          label: "JIKA / ULANGI / SALIN",
          text: "Percabangan, perulangan, dan menyalin nilai ke himpunan data lain.",
        },
      ],
      image: "images/bab-algoritma.jpg",
      imageCaption:
        "Memasak nasi goreng di warung: urutan langkah yang pasti menghasilkan masakan yang sama setiap kali.",
      caseTitle: "Contoh Kasus — Algoritma Menghitung Ketuntasan Nilai",
      caseIntro:
        "Pak Budi ingin mengetahui siapa saja yang perlu remedial dari himpunan data nilai satu kelas. Perintahnya cukup sederhana dan dapat ditulis dalam pseudocode berkosakata terbatas.",
      caseSteps: [
        "MULAI",
        "BACA himpunan data nilai ulangan",
        "ULANGI setiap baris pada himpunan data",
        "   HITUNG rata = nilai kelas",
        "   JIKA nilai < 75 MAKA TULIS nama, “Remedial” SELAINYA TULIS nama, “Tuntas”",
        "SELESAI",
      ],
      caseNote:
        "Perhatikan: tidak ada satu pun kata di luar kosakata yang disepakati. Batasan inilah yang membuat pseudocode dapat dipahami orang lain dengan pasti.",
    },
  ],
  slides: [
    {
      id: "s1",
      kicker: "Slide 01 · Pembuka",
      title: "Elemen Berpikir Komputasional",
      lead: "Informatika Fase D · SMP Negeri 2 Ngadirejo",
      bullets: [
        "Guru: Budi Winarno, S.Kom",
        "Alokasi waktu: 4 × 40 menit (2 pertemuan)",
        "Media: modul ajar interaktif, LKPD, dan kuis daring",
      ],
      note: "Salam pembuka, doa bersama, lalu tampilkan pertanyaan pemantik: “Apa persamaan daftar nilai, jadwal pelajaran, dan data perpustakaan?”",
      variant: "cover",
    },
    {
      id: "s2",
      kicker: "Slide 02 · Pemantik",
      title: "Perhatikan di Sekitarmu",
      lead: "Masalah besar selalu terlihat rumit sampai kita memecahnya.",
      bullets: [
        "Bagaimana panitia membagi tugas piket kelas 28 siswa?",
        "Bagaimana Bu Yem menebak jumlah nasi goreng yang harus dimasak?",
        "Bagaimana peta sederhana menunjukkan jalan ke sekolah?",
      ],
      note: "Berikan waktu 3 menit untuk diskusi berpasangan, lalu minta 2 pasang menyampaikan jawaban.",
      variant: "bullets",
    },
    {
      id: "s3",
      kicker: "Slide 03 · Capaian",
      title: "Capaian Pembelajaran",
      lead: "Apa yang harus dikuasai peserta didik pada akhir modul ini?",
      bullets: [
        "Memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari.",
        "Menerapkan berpikir komputasional pada persoalan data berstruktur sederhana bervolume kecil.",
        "Mendisposisikan berpikir komputasional pada berbagai bidang.",
        "Menuliskan instruksi dengan kosakata terbatas dalam format pseudocode.",
      ],
      note: "Bacakan capaian dengan kalimat sederhana agar siswa mengerti tujuan pembelajaran hari ini.",
      variant: "bullets",
    },
    {
      id: "s4",
      kicker: "Slide 04 · Alur Tujuan",
      title: "Tujuan & Alur Tujuan Pembelajaran",
      lead: "Memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari.",
      bullets: [
        "ATP: memahami konsep himpunan data terstruktur dalam kehidupan sehari-hari.",
        "Langkah 1 — mengenali baris, kolom, dan judul kolom.",
        "Langkah 2 — memilah data terstruktur dan tidak terstruktur.",
        "Langkah 3 — menuliskan langkah pengolahan data dalam pseudocode.",
      ],
      note: "Tuliskan tujuan di papan tulis; siswa menyalin pada buku catatan mereka.",
      variant: "bullets",
    },
    {
      id: "s5",
      kicker: "Slide 05 · Konsep",
      title: "Himpunan Data Terstruktur",
      lead: "Data tersusun dalam baris dan kolom dengan aturan tetap.",
      bullets: [
        "Baris (record) = satu objek utuh, misalnya satu siswa.",
        "Kolom (field) = satu jenis informasi yang sama.",
        "Judul kolom menjelaskan isi kolom.",
        "Contoh: daftar nilai, jadwal pelajaran, absensi piket.",
      ],
      note: "Tunjukkan daftar nilai kelas yang sebenarnya (ditiadakan nama asli) sebagai contoh nyata.",
      variant: "bullets",
    },
    {
      id: "s6",
      kicker: "Slide 06 · Contoh Kasus",
      title: "Daftar Nilai VIIIB",
      lead: "Sebuah himpunan data kecil yang dapat dihitung manual.",
      bullets: [
        "28 baris data siswa, 4 kolom: No, Nama, Nilai, Ketuntasan.",
        "Nilai tertinggi 96 · terendah 54 · rata-rata 78,6.",
        "Kolom Ketuntasan diisi dari aturan: nilai < 75 → Remedial.",
        "Pertanyaan: bagaimana jika barisnya 400 siswa?",
      ],
      note: "Ajak siswa menghitung manual dulu, baru bertanya: bagaimana cara komputer melakukannya?",
      variant: "case",
    },
    {
      id: "s7",
      kicker: "Slide 07 · Elemen 1",
      title: "Dekomposisi",
      lead: "Memecah masalah besar menjadi bagian kecil.",
      bullets: [
        "Masalah besar → sub-masalah kecil yang mudah dikerjakan.",
        "Contoh: class meeting → perlengkapan, konsumsi, acara, dokumentasi.",
        "Setiap bagian punya penanggung jawab dan urutan sendiri.",
      ],
      note: "Latihan cepat: pecah tugas “membuat mading kelas” menjadi 4 bagian.",
      variant: "bullets",
    },
    {
      id: "s8",
      kicker: "Slide 08 · Elemen 2",
      title: "Pengenalan Pola",
      lead: "Menemukan hal yang berulang agar solusi dapat dipakai ulang.",
      bullets: [
        "Pola pada data: nilai yang sering muncul, kode kelas yang berulang.",
        "Pola pada kejadian: antrian kantin yang ramai pada jam yang sama.",
        "Manfaat: template, rumus, dan perulangan (loop).",
      ],
      note: "Minta siswa menyebutkan satu pola yang mereka lihat hari ini.",
      variant: "bullets",
    },
    {
      id: "s9",
      kicker: "Slide 09 · Elemen 3",
      title: "Abstraksi",
      lead: "Mengambil yang penting, menyingkirkan yang tidak perlu.",
      bullets: [
        "Peta rute rumah–sekolah tidak menggambarkan setiap pohon.",
        "Data perpustakaan cukup: nomor kartu, nama, kelas.",
        "Menentukan kolom sebuah himpunan data = melakukan abstraksi.",
      ],
      note: "Bandingkan foto asli jalan dengan peta sederhananya agar konsep abstraksi terasa.",
      variant: "bullets",
    },
    {
      id: "s10",
      kicker: "Slide 10 · Elemen 4",
      title: "Algoritma & Pseudocode",
      lead: "Menuliskan sekumpulan instruksi dengan kosakata terbatas.",
      bullets: [
        "Kosakata: MULAI, SELESAI, BACA, TULIS, HITUNG, JIKA…MAKA…SELAINYA…, ULANGI…SAMPAI…, SALIN.",
        "Contoh: menghitung ketuntasan nilai satu kelas.",
        "Bahasa setengah manusia, setengah program — tanpa ambiguitas.",
      ],
      note: "Tulis pseudocode di papan bersama-sama, satu baris satu siswa maju.",
      variant: "case",
    },
    {
      id: "s11",
      kicker: "Slide 11 · Diagram Alur",
      title: "Diagram Alur Menentukan Ketuntasan",
      lead: "Keputusan sederhana digambar dengan simbol baku.",
      bullets: [
        "Persegi = proses · Belah ketupat = keputusan · Panah = arah aliran.",
        "Awal dan akhir ditulis di simbol oval.",
        "Diagram yang sama dapat ditulis kembali menjadi pseudocode.",
      ],
      note: "Arahkan ke diagram alur pada halaman Materi bab 05.",
      variant: "case",
    },
    {
      id: "s12",
      kicker: "Slide 12 · Penutup",
      title: "Rangkuman & Tugas",
      lead: "Empat elemen berpikir komputasional, satu tujuan: masalah selesai dengan pasti.",
      bullets: [
        "Dekomposisi memecah masalah, pola menghemat pekerjaan.",
        "Abstraksi menentukan data penting, algoritma menuliskan langkah.",
        "Kerjakan LKPD 5 aktivitas, lalu kuis 20 soal acak.",
        "Sampaikan kesan pada kolom komentar siswa.",
      ],
      note: "Tutup dengan refleksi 2 menit: “Elemen mana yang paling membantu pekerjaanmu hari ini?”",
      variant: "recap",
    },
  ],
  lkpd: {
    intro:
      "Lembar Kerja Peserta Didik (LKPD) dikerjakan secara mandiri atau berpasangan. Isi identitas dengan benar — nama dan kelas akan tersimpan bersama seluruh jawabanmu dan menjadi bahan penilaian guru.",
    tasks: [
      {
        id: "t1",
        step: "Aktivitas 1",
        activity: "Mengenali Himpunan Data Terstruktur",
        instruction:
          "Amati lingkungan sekolahmu selama satu hari. Tuliskan tiga contoh himpunan data terstruktur yang kamu temukan, lengkap dengan nama kolomnya.",
        questions: [
          {
            id: "t1q1",
            text: "Tiga contoh himpunan data terstruktur yang kamu temukan beserta kolomnya:",
            lines: 4,
          },
          {
            id: "t1q2",
            text: "Apa tanda sebuah kumpulan data sudah dapat dikatakan terstruktur?",
            lines: 3,
          },
        ],
      },
      {
        id: "t2",
        step: "Aktivitas 2",
        activity: "Dekomposisi Kegiatan Sekolah",
        instruction:
          "Pilih satu kegiatan di sekolah (misalnya class meeting, lomba 17-an, atau piket kelas). Pecah kegiatan itu menjadi minimal empat bagian kecil yang dapat dikerjakan terpisah.",
        questions: [
          {
            id: "t2q1",
            text: "Nama kegiatan dan empat bagian hasil pemecahanmu:",
            lines: 4,
          },
          {
            id: "t2q2",
            text: "Bagian mana yang paling sulit menurutmu, dan mengapa?",
            lines: 3,
          },
        ],
      },
      {
        id: "t3",
        step: "Aktivitas 3",
        activity: "Mencari Pola pada Data Kelas",
        instruction:
          "Perhatikan daftar nilai ulangan matematika berikut: 78, 65, 82, 78, 90, 65, 78, 88, 74, 90. Temukan pola yang berulang dan tuliskan kesimpulanmu.",
        questions: [
          {
            id: "t3q1",
            text: "Nilai mana yang berulang dan berapa kali kemunculannya?",
            lines: 3,
          },
          {
            id: "t3q2",
            text: "Kesimpulan yang dapat diambil dari pola tersebut:",
            lines: 3,
          },
        ],
      },
      {
        id: "t4",
        step: "Aktivitas 4",
        activity: "Melatih Abstraksi",
        instruction:
          "Bayangkan kamu membuat himpunan data peserta lomba antar kelas. Tentukan kolom yang benar-benar perlu disimpan dan buang informasi yang tidak penting.",
        questions: [
          {
            id: "t4q1",
            text: "Minimal 4 kolom yang kamu simpan beserta alasannya:",
            lines: 4,
          },
          {
            id: "t4q2",
            text: "Informasi apa yang kamu buang, dan mengapa tidak diperlukan?",
            lines: 3,
          },
        ],
      },
      {
        id: "t5",
        step: "Aktivitas 5",
        activity: "Menulis Pseudocode Berkosakata Terbatas",
        instruction:
          "Tuliskan pseudocode untuk menghitung jumlah siswa yang tuntas (nilai ≥ 75) pada sebuah himpunan data nilai. Gunakan hanya kosakata: MULAI, SELESAI, BACA, TULIS, HITUNG, JIKA…MAKA…SELAINYA…, ULANGI…SAMPAI…, SALIN.",
        questions: [
          {
            id: "t5q1",
            text: "Pseudocode buatanmu (gunakan baris demi baris):",
            lines: 6,
          },
          {
            id: "t5q2",
            text: "Elemen berpikir komputasional mana yang paling terasa saat mengerjakan LKPD ini? Jelaskan!",
            lines: 3,
          },
        ],
      },
    ],
  },
  quiz: {
    intro:
      "Kuis terdiri atas 25 soal bank, namun setiap siswa mengerjakan 20 soal yang diacak urutannya beserta pilihan jawabannya. Nilai dihitung dari jumlah jawaban benar dan disimpan bersama nama serta kelasmu.",
    questions: [
      {
        id: "q01",
        topic: "Himpunan Data",
        question: "Manakah yang termasuk himpunan data terstruktur?",
        options: [
          "Coretan bebas di papan tulis",
          "Daftar nilai ulangan dengan kolom No, Nama, dan Nilai",
          "Rekaman suara upacara bendera",
          "Kumpulan foto kegiatan class meeting",
        ],
        answer: 1,
        explanation:
          "Himpunan data terstruktur disusun dalam baris dan kolom dengan judul kolom yang tetap, seperti daftar nilai.",
      },
      {
        id: "q02",
        topic: "Himpunan Data",
        question: "Dalam sebuah daftar siswa, satu baris menunjukkan …",
        options: [
          "Satu jenis informasi untuk semua siswa",
          "Satu objek utuh, misalnya satu siswa beserta datanya",
          "Judul dari seluruh tabel",
          "Jumlah seluruh siswa",
        ],
        answer: 1,
        explanation:
          "Satu baris (record) berisi data utuh dari satu objek, misalnya satu siswa.",
      },
      {
        id: "q03",
        topic: "Himpunan Data",
        question: "Fungsi judul kolom pada himpunan data adalah …",
        options: [
          "Memperindah tampilan tabel saja",
          "Menjelaskan jenis isi dari kolom tersebut",
          "Menentukan urutan siswa",
          "Menghitung jumlah baris",
        ],
        answer: 1,
        explanation:
          "Judul kolom menjelaskan isi kolom agar data dapat dipahami orang lain tanpa penjelasan tambahan.",
      },
      {
        id: "q04",
        topic: "Himpunan Data",
        question: "Yang termasuk contoh himpunan data terstruktur di sekolah adalah …",
        options: [
          "Jadwal pelajaran mingguan",
          "Percakapan siswa di kantin",
          "Video pembelajaran",
          "Papan mading yang dicoret bebas",
        ],
        answer: 0,
        explanation:
          "Jadwal pelajaran memiliki baris (jam) dan kolom (hari) yang tetap sehingga terstruktur.",
      },
      {
        id: "q05",
        topic: "Himpunan Data",
        question: "Ciri data tidak terstruktur adalah …",
        options: [
          "Tersusun dalam baris dan kolom",
          "Mudah dihitung dengan rumus",
          "Tidak punya aturan susunan yang tetap",
          "Selalu berupa angka",
        ],
        answer: 2,
        explanation:
          "Data tidak terstruktur tidak memiliki aturan susunan, misalnya foto, suara, atau tulisan bebas.",
      },
      {
        id: "q06",
        topic: "Dekomposisi",
        question: "Dekomposisi adalah proses …",
        options: [
          "Mencari hal yang berulang",
          "Memecah masalah besar menjadi bagian kecil",
          "Menyimpan data ke dalam tabel",
          "Menulis urutan langkah program",
        ],
        answer: 1,
        explanation:
          "Dekomposisi memecah masalah besar menjadi sub-masalah kecil yang mudah dikerjakan.",
      },
      {
        id: "q07",
        topic: "Dekomposisi",
        question: "Contoh penerapan dekomposisi yang tepat adalah …",
        options: [
          "Mengerjakan seluruh tugas bazar sekaligus sendirian",
          "Membagi tugas bazar menjadi perlengkapan, konsumsi, acara, dan dokumentasi",
          "Menunggu teman mengerjakan semuanya",
          "Menghapus bagian yang sulit dari rencana",
        ],
        answer: 1,
        explanation:
          "Membagi tugas besar menjadi beberapa bagian kecil adalah inti dari dekomposisi.",
      },
      {
        id: "q08",
        topic: "Dekomposisi",
        question: "Manfaat dekomposisi dalam mengerjakan tugas kelompok adalah …",
        options: [
          "Pekerjaan selesai tanpa perlu perencanaan",
          "Setiap anggota tahu bagian yang harus dikerjakan",
          "Jumlah pekerjaan menjadi bertambah",
          "Tidak perlu memeriksa hasil kerja",
        ],
        answer: 1,
        explanation:
          "Dengan pemecahan bagian, tanggung jawab menjadi jelas dan pekerjaan dapat berjalan paralel.",
      },
      {
        id: "q09",
        topic: "Dekomposisi",
        question:
          "Mengolah daftar nilai kelas dapat dipecah menjadi langkah berikut, kecuali …",
        options: [
          "Mengumpulkan data nilai",
          "Merapikan baris dan kolom",
          "Menghitung rata-rata",
          "Menghias lembar daftar nilai dengan gambar",
        ],
        answer: 3,
        explanation:
          "Menghias lembar bukan bagian penting dalam mengolah data nilai.",
      },
      {
        id: "q10",
        topic: "Pengenalan Pola",
        question: "Pengenalan pola bertujuan untuk …",
        options: [
          "Menemukan kesamaan atau keteraturan yang berulang",
          "Menambah jumlah data",
          "Menghapus data yang salah",
          "Mengurutkan nama siswa",
        ],
        answer: 0,
        explanation:
          "Pengenalan pola mencari kesamaan, keteraturan, atau perulangan agar solusi dapat dipakai ulang.",
      },
      {
        id: "q11",
        topic: "Pengenalan Pola",
        question: "Pola pada himpunan data nilai ulangan dapat berupa …",
        options: [
          "Warna kertas yang dipakai",
          "Nilai yang paling sering muncul",
          "Ukuran huruf judul kolom",
          "Jumlah baris pada kertas",
        ],
        answer: 1,
        explanation:
          "Nilai yang sering muncul (modus) merupakan salah satu pola yang dapat ditemukan pada data.",
      },
      {
        id: "q12",
        topic: "Pengenalan Pola",
        question:
          "Setiap jam 09.30 antrian warung kantin selalu ramai. Temuan ini termasuk …",
        options: [
          "Abstraksi",
          "Dekomposisi",
          "Pola keteraturan pada kejadian",
          "Pseudocode",
        ],
        answer: 2,
        explanation:
          "Keterulangan kejadian pada waktu yang sama adalah pola yang dapat dipakai untuk mengambil keputusan.",
      },
      {
        id: "q13",
        topic: "Pengenalan Pola",
        question: "Manfaat menemukan pola pada masalah adalah …",
        options: [
          "Solusi lama dapat dipakai untuk masalah baru",
          "Masalah menjadi lebih rumit",
          "Data menjadi tidak terstruktur",
          "Langkah algoritma harus ditulis ulang",
        ],
        answer: 0,
        explanation:
          "Karena polanya sama, penyelesaian yang sudah ada dapat digunakan kembali tanpa membuat dari awal.",
      },
      {
        id: "q14",
        topic: "Abstraksi",
        question: "Abstraksi adalah proses …",
        options: [
          "Menambah rincian sebanyak mungkin",
          "Menyaring informasi sehingga hanya hal penting yang disimpan",
          "Menghapus seluruh data",
          "Menyusun langkah berurutan",
        ],
        answer: 1,
        explanation:
          "Abstraksi menyimpan hal yang relevan dengan tujuan dan membuang rincian yang tidak diperlukan.",
      },
      {
        id: "q15",
        topic: "Abstraksi",
        question: "Pada peta rute rumah ke sekolah, yang termasuk hasil abstraksi adalah …",
        options: [
          "Semua pohon yang dilalui",
          "Warna cat setiap rumah",
          "Titik penting seperti persimpangan dan gerbang sekolah",
          "Nama seluruh penghuni rumah",
        ],
        answer: 2,
        explanation:
          "Hanya titik penting yang membantu mencapai tujuan yang dipertahankan pada peta.",
      },
      {
        id: "q16",
        topic: "Abstraksi",
        question:
          "Untuk keperluan peminjaman buku perpustakaan, kolom yang TIDAK diperlukan adalah …",
        options: ["Nomor kartu anggota", "Nama siswa", "Kelas", "Hobi siswa"],
        answer: 3,
        explanation:
          "Hobi tidak berpengaruh pada proses peminjaman, sehingga disingkirkan melalui abstraksi.",
      },
      {
        id: "q17",
        topic: "Abstraksi",
        question: "Dalam pseudocode, menulis “BACA data nilai” tanpa menjelaskan cara kerja keyboard merupakan penerapan …",
        options: ["Dekomposisi", "Abstraksi", "Pola", "Simulasi"],
        answer: 1,
        explanation:
          "Detail teknis disembunyikan agar langkah utama algoritma tetap jelas — itulah abstraksi.",
      },
      {
        id: "q18",
        topic: "Algoritma",
        question: "Algoritma adalah …",
        options: [
          "Kumpulan data yang tersusun rapi",
          "Urutan langkah yang runtut dan berhenti untuk menyelesaikan masalah",
          "Program komputer yang sudah jadi",
          "Gambar diagram alur",
        ],
        answer: 1,
        explanation:
          "Algoritma adalah urutan langkah yang runtut, terbatas, dan berakhir untuk mencapai tujuan.",
      },
      {
        id: "q19",
        topic: "Algoritma",
        question: "Contoh algoritma dalam kehidupan sehari-hari adalah …",
        options: [
          "Resep memasak nasi goreng",
          "Warna dinding kelas",
          "Daftar hadir siswa",
          "Foto wisata keluarga",
        ],
        answer: 0,
        explanation:
          "Resep masakan berisi urutan langkah yang harus diikuti secara berurutan.",
      },
      {
        id: "q20",
        topic: "Pseudocode",
        question: "Kosakata yang sah dipakai dalam pseudocode modul ini adalah …",
        options: [
          "MULAI, BACA, TULIS, HITUNG, SELESAI",
          "BUKA, KLIK, GESER, TUTUP",
          "LIHAT, DENGAR, RASAKAN",
          "KETUK, GULIR, TAHAN, LEPAS",
        ],
        answer: 0,
        explanation:
          "Kosakata yang disepakati: MULAI, SELESAI, BACA, TULIS, HITUNG, JIKA, ULANGI, SALIN.",
      },
      {
        id: "q21",
        topic: "Pseudocode",
        question:
          "Baris “JIKA nilai < 75 MAKA TULIS “Remedial” SELAINYA TULIS “Tuntas”” termasuk bagian …",
        options: ["Perulangan", "Percabangan", "Masukan data", "Dekomposisi"],
        answer: 1,
        explanation:
          "JIKA…MAKA…SELAINYA… adalah percabangan karena ada dua kemungkinan hasil keputusan.",
      },
      {
        id: "q22",
        topic: "Pseudocode",
        question:
          "Untuk memproses setiap baris pada himpunan data nilai, kosakata yang digunakan adalah …",
        options: ["SALIN", "HITUNG", "ULANGI … SAMPAI …", "TULIS"],
        answer: 2,
        explanation:
          "ULANGI … SAMPAI … dipakai untuk perulangan, misalnya memproses baris satu per satu.",
      },
      {
        id: "q23",
        topic: "Pseudocode",
        question: "Urutan pseudocode yang benar untuk menghitung rata-rata nilai adalah …",
        options: [
          "MULAI, HITUNG, BACA, SELESAI",
          "MULAI, BACA data nilai, HITUNG rata-rata, TULIS hasil, SELESAI",
          "BACA, MULAI, TULIS, SELESAI",
          "TULIS, HITUNG, BACA, MULAI",
        ],
        answer: 1,
        explanation:
          "Algoritma dimulai dengan MULAI, lalu masukan diambil dengan BACA sebelum dihitung dan ditampilkan.",
      },
      {
        id: "q24",
        topic: "Penerapan",
        question:
          "Panitia ingin mengetahui siswa yang belum membayar kontribusi dari himpunan data kelas. Langkah pertama yang paling tepat adalah …",
        options: [
          "Langsung mengecek satu per satu secara acak",
          "Melakukan dekomposisi: menentukan kolom yang diperlukan dan aturan pengecekan",
          "Menghapus data siswa yang sudah membayar",
          "Menyusun ulang nama siswa secara acak",
        ],
        answer: 1,
        explanation:
          "Masalah dipecah lebih dahulu: kolom apa yang diperlukan dan aturan apa yang dipakai untuk menilai.",
      },
      {
        id: "q25",
        topic: "Penerapan",
        question:
          "Perhatikan data berikut: 78, 65, 82, 78, 90, 65, 78. Pola yang paling menonjol adalah …",
        options: [
          "Nilai selalu naik",
          "Nilai 78 paling sering muncul (3 kali)",
          "Semua nilai berbeda",
          "Nilai terbesar adalah 65",
        ],
        answer: 1,
        explanation:
          "Nilai 78 muncul tiga kali sehingga menjadi modus; ini adalah contoh pengenalan pola pada data.",
      },
    ],
  },
};
