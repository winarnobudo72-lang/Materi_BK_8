export const KELAS_LIST = [
  "VIIIA",
  "VIIIB",
  "VIIIC",
  "VIIID",
  "VIIIE",
  "VIIIF",
  "VIIIG",
];

export type Section = {
  id: string;
  no: string;
  kicker: string;
  title: string;
  lead: string;
  body: string[];
  points: { label: string; text: string }[];
  image: string;
  imageCaption: string;
  caseTitle: string;
  caseIntro: string;
  caseSteps: string[];
  caseNote: string;
};

export type Slide = {
  id: string;
  kicker: string;
  title: string;
  lead: string;
  bullets: string[];
  note: string;
  variant: "cover" | "bullets" | "case" | "recap";
};

export type LkpdQuestion = { id: string; text: string; lines: number };
export type LkpdTask = {
  id: string;
  step: string;
  activity: string;
  instruction: string;
  questions: LkpdQuestion[];
};

export type QuizQuestion = {
  id: string;
  topic: string;
  question: string;
  options: string[];
  answer: number;
  explanation: string;
};

export type ModuleMeta = {
  school: string;
  phase: string;
  teacher: string;
  subject: string;
  material: string;
  time: string;
  title: string;
  subtitle: string;
  capaian: string;
  tujuan: string;
  atp: string;
  profilPelajar: string;
};

export type ModuleContent = {
  meta: ModuleMeta;
  sections: Section[];
  slides: Slide[];
  lkpd: { intro: string; tasks: LkpdTask[] };
  quiz: { intro: string; questions: QuizQuestion[] };
};
