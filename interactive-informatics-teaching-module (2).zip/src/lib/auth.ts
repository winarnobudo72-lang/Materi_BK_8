import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";

const SECRET = process.env.MODUL_SECRET ?? "smp2ngadirejo-informatika-fase-d";
export const ADMIN_USER = process.env.ADMIN_USER ?? "admin";
export const ADMIN_PASS = process.env.ADMIN_PASS ?? "budi2026";
export const SESSION_COOKIE = "modul_ajar_admin";
const TTL_MS = 1000 * 60 * 60 * 8;

function hmac(payload: string) {
  return createHmac("sha256", SECRET).update(payload).digest("hex");
}

function sign(payload: string) {
  return `${payload}.${hmac(payload)}`;
}

export function verify(token: string | undefined): boolean {
  if (!token) return false;
  const idx = token.lastIndexOf(".");
  if (idx < 0) return false;
  const payload = token.slice(0, idx);
  const sig = token.slice(idx + 1);
  const expected = hmac(payload);
  if (sig.length !== expected.length) return false;
  try {
    if (!timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return false;
  } catch {
    return false;
  }
  const [user, exp] = payload.split("|");
  if (user !== ADMIN_USER) return false;
  const expires = Number(exp);
  return Number.isFinite(expires) && expires > Date.now();
}

export function checkCredentials(user: string, pass: string) {
  const a = Buffer.from(user);
  const b = Buffer.from(ADMIN_USER);
  const c = Buffer.from(pass);
  const d = Buffer.from(ADMIN_PASS);
  const userOk = a.length === b.length && timingSafeEqual(a, b);
  const passOk = c.length === d.length && timingSafeEqual(c, d);
  return userOk && passOk;
}

export async function createSession() {
  const token = sign(`${ADMIN_USER}|${Date.now() + TTL_MS}`);
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: TTL_MS / 1000,
  });
}

export async function destroySession() {
  const jar = await cookies();
  jar.delete(SESSION_COOKIE);
}

export async function isAuthenticated() {
  const jar = await cookies();
  return verify(jar.get(SESSION_COOKIE)?.value);
}
