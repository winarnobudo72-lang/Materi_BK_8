import KuisClient from "@/components/KuisClient";
import { getContent, getExamSet } from "@/lib/repo";

export const dynamic = "force-dynamic";

export default async function KuisPage() {
  const { quiz, meta } = await getContent();
  const exam = await getExamSet();

  return (
    <div className="mx-auto max-w-[1240px] px-5">
      <header className="pt-12 pb-10 border-b-[3px] border-ink">
        <p className="mono-label text-stamp">
          Evaluasi · {meta.material} · {meta.phase}
        </p>
        <h1 className="display text-[clamp(38px,6vw,68px)] mt-3">
          Kuis Berpikir Komputasional
        </h1>
        <p className="mt-5 measure text-[16.5px] text-ink/85">{quiz.intro}</p>
        <p className="mono text-[12px] text-ink-soft mt-4">
          Paket soal ini berisi {exam.length} soal acak dari {quiz.questions.length} soal bank ·
          urutan soal dan pilihan jawaban diacak untuk setiap siswa.
        </p>
      </header>

      <div className="py-12">
        <KuisClient questions={exam} intro={quiz.intro} />
      </div>
    </div>
  );
}
