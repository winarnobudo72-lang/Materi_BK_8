import Slides from "@/components/Slides";
import { getContent } from "@/lib/repo";

export const dynamic = "force-dynamic";

export default async function SlidePage() {
  const { slides, meta } = await getContent();

  return (
    <div>
      <header className="mx-auto max-w-[1240px] px-5 pt-12 pb-8">
        <p className="mono-label text-stamp">
          Slide Presentasi · {meta.material} · {meta.school}
        </p>
        <h1 className="display text-[clamp(36px,5.5vw,62px)] mt-3">
          {slides.length} slide siap tayang di kelas
        </h1>
        <p className="mt-4 measure text-[16.5px] text-ink/80">
          Gunakan tombol panah pada papan ketik untuk berpindah. Setiap slide disertai catatan
          guru berisi saran kegiatan saat penyajian.
        </p>
      </header>
      <Slides slides={slides} />
    </div>
  );
}
