import { NextRequest } from "next/server";
import {
  gradeQuiz,
  saveComment,
  saveLkpd,
  saveQuizResult,
  type QuizAnswerRow,
} from "@/lib/repo";
import { KELAS_LIST } from "@/lib/types";

export const dynamic = "force-dynamic";

function clean(value: unknown, max = 120) {
  return String(value ?? "").trim().slice(0, max);
}

export async function POST(req: NextRequest) {
  const body = (await req.json()) as {
    type?: string;
    studentName?: string;
    className?: string;
    answers?: unknown;
    message?: string;
  };

  const studentName = clean(body.studentName);
  const className = clean(body.className, 12);

  if (body.type === "comment") {
    const message = clean(body.message, 800);
    if (!studentName || !className || !message) {
      return Response.json(
        { ok: false, message: "Nama, kelas, dan komentar wajib diisi." },
        { status: 400 },
      );
    }
    const row = await saveComment({ studentName, className, message });
    return Response.json({ ok: true, id: row?.id });
  }

  if (!studentName || !KELAS_LIST.includes(className)) {
    return Response.json(
      { ok: false, message: "Isi nama dan pilih kelas terlebih dahulu." },
      { status: 400 },
    );
  }

  if (body.type === "lkpd") {
    const row = await saveLkpd({
      studentName,
      className,
      answers: body.answers ?? {},
    });
    return Response.json({ ok: true, id: row?.id });
  }

  if (body.type === "quiz") {
    const rows = Array.isArray(body.answers) ? (body.answers as QuizAnswerRow[]) : [];
    const graded = await gradeQuiz(rows);
    const row = await saveQuizResult({
      studentName,
      className,
      score: graded.score,
      correct: graded.correct,
      total: graded.total,
      answers: graded.detail,
    });
    return Response.json({
      ok: true,
      id: row?.id,
      score: graded.score,
      correct: graded.correct,
      total: graded.total,
      detail: graded.detail,
    });
  }

  return Response.json({ ok: false, message: "Jenis permintaan tidak dikenal." }, { status: 400 });
}
