import { NextRequest } from "next/server";
import { isAuthenticated } from "@/lib/auth";
import { listComments, listLkpd, listQuizResults } from "@/lib/repo";

export const dynamic = "force-dynamic";

function csv(rows: (string | number)[][]) {
  const esc = (v: string | number) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return rows.map((r) => r.map(esc).join(",")).join("\r\n");
}

function fmt(date: Date | string) {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("id-ID", {
    dateStyle: "medium",
    timeStyle: "medium",
    timeZone: "Asia/Jakarta",
  }).format(d);
}

function flat(value: unknown) {
  const data = value as Record<string, unknown> | unknown[] | null;
  if (!data) return "";
  if (Array.isArray(data)) return JSON.stringify(data);
  return Object.entries(data)
    .map(([k, v]) => `${k}: ${String(v ?? "").replace(/\s+/g, " ")}`)
    .join(" | ");
}

export async function GET(req: NextRequest) {
  if (!(await isAuthenticated())) {
    return Response.json({ ok: false, message: "Sesi admin tidak sah." }, { status: 401 });
  }
  const type = new URL(req.url).searchParams.get("type") ?? "quiz";

  let body = "";
  let name = "nilai-kuis.csv";

  if (type === "lkpd") {
    const rows = await listLkpd();
    body = csv([
      ["No", "Nama Siswa", "Kelas", "Jawaban LKPD", "Waktu Pengumpulan"],
      ...rows.map((r, i) => [
        rows.length - i,
        r.studentName,
        r.className,
        flat(r.answers),
        fmt(r.createdAt),
      ]),
    ]);
    name = "jawaban-lkpd.csv";
  } else if (type === "comments") {
    const rows = await listComments();
    body = csv([
      ["No", "Nama Siswa", "Kelas", "Komentar", "Waktu"],
      ...rows.map((r, i) => [
        rows.length - i,
        r.studentName,
        r.className,
        r.message,
        fmt(r.createdAt),
      ]),
    ]);
    name = "komentar-siswa.csv";
  } else {
    const rows = await listQuizResults();
    body = csv([
      ["No", "Nama Siswa", "Kelas", "Nilai", "Benar", "Total", "Waktu"],
      ...rows.map((r, i) => [
        rows.length - i,
        r.studentName,
        r.className,
        r.score,
        r.correct,
        r.total,
        fmt(r.createdAt),
      ]),
    ]);
    name = "nilai-kuis.csv";
  }

  return new Response("\uFEFF" + body, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${name}"`,
    },
  });
}
