import { NextRequest } from "next/server";
import { isAuthenticated } from "@/lib/auth";
import {
  getContent,
  listComments,
  listLkpd,
  listQuizResults,
  saveContent,
} from "@/lib/repo";

export const dynamic = "force-dynamic";

const ALLOWED = ["meta", "sections", "slides", "lkpd", "quiz"] as const;

export async function GET() {
  if (!(await isAuthenticated())) {
    return Response.json({ ok: false, message: "Sesi admin tidak sah." }, { status: 401 });
  }
  const [quiz, lkpd, comments, content] = await Promise.all([
    listQuizResults(),
    listLkpd(),
    listComments(),
    getContent(),
  ]);
  return Response.json({ ok: true, quiz, lkpd, comments, content });
}

export async function POST(req: NextRequest) {
  if (!(await isAuthenticated())) {
    return Response.json({ ok: false, message: "Sesi admin tidak sah." }, { status: 401 });
  }
  const body = (await req.json()) as { key?: string; value?: unknown };
  const key = body.key as (typeof ALLOWED)[number];
  if (!ALLOWED.includes(key)) {
    return Response.json({ ok: false, message: "Kunci konten tidak dikenal." }, { status: 400 });
  }
  await saveContent(key, body.value);
  return Response.json({ ok: true });
}
