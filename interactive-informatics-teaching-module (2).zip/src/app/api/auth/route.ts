import { NextRequest } from "next/server";
import { checkCredentials, createSession, destroySession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  const body = (await req.json()) as {
    action?: string;
    user?: string;
    pass?: string;
  };

  if (body.action === "logout") {
    await destroySession();
    return Response.json({ ok: true });
  }

  const user = (body.user ?? "").trim();
  const pass = body.pass ?? "";
  if (!checkCredentials(user, pass)) {
    return Response.json(
      { ok: false, message: "Nama pengguna atau kata sandi salah." },
      { status: 401 },
    );
  }
  await createSession();
  return Response.json({ ok: true });
}
