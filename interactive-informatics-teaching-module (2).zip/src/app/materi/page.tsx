import Image from "next/image";
import SpineNav from "@/components/SpineNav";
import { FlowchartKetuntasan } from "@/components/Flowchart";
import { getContent } from "@/lib/repo";

export const dynamic = "force-dynamic";

export default async function MateriPage() {
  const { meta, sections } = await getContent();
  const spine = sections.map((s) => ({ id: s.id, no: s.no, title: s.title }));

  return (
    <div className="mx-auto max-w-[1240px] px-5">
      {/* Kepala halaman */}
      <header className="pt-12 pb-10 border-b-[3px] border-ink">
        <p className="mono-label text-stamp">
          Materi Lengkap · {meta.material} · {meta.phase}
        </p>
        <h1 className="display text-[clamp(38px,6vw,68px)] mt-3 max-w-[16ch]">
          Membaca Dunia sebagai Himpunan Data
        </h1>
        <p className="mt-5 measure text-[17px] text-ink/80">
          Lima bab berikut disusun berurutan: dari mengenali data terstruktur, memecah masalah,
          menemukan pola, menyaring yang penting, hingga menuliskan instruksi dalam pseudocode
          berkosakata terbatas. Setiap bab dilengkapi ilustrasi dan contoh kasus kehidupan
          sehari-hari.
        </p>
      </header>

      <div className="grid gap-12 lg:grid-cols-[210px_minmax(0,1fr)] py-12">
        <SpineNav items={spine} />

        <div className="space-y-24">
          {sections.map((s) => (
            <article key={s.id} id={s.id} className="scroll-mt-32">
              <div className="grid gap-10 xl:grid-cols-[minmax(0,62ch)_minmax(0,320px)]">
                <div>
                  <p className="mono-label text-stamp">{s.kicker}</p>
                  <h2 className="display text-[clamp(30px,3.4vw,44px)] mt-3">{s.title}</h2>
                  <p className="mt-5 font-display text-[20px] italic leading-[1.5] text-ink/85">
                    {s.lead}
                  </p>
                  <div className="mt-6 space-y-5 text-[16.5px] leading-[1.75] measure">
                    {s.body.map((p, i) => (
                      <p key={i}>{p}</p>
                    ))}
                  </div>

                  <div className="mt-8 border-t-[3px] border-ink">
                    {s.points.map((pt) => (
                      <div
                        key={pt.label}
                        className="grid sm:grid-cols-[190px_minmax(0,1fr)] gap-2 sm:gap-5 py-3 border-b border-ink/15"
                      >
                        <p className="mono text-[12px] uppercase tracking-[0.12em] text-ink-soft pt-1">
                          {pt.label}
                        </p>
                        <p className="text-[15.5px]">{pt.text}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <aside className="space-y-6 xl:sticky xl:top-32 self-start">
                  <figure className="border border-ink/25 paper-edge bg-paper-2/40">
                    <div className="relative h-[190px] overflow-hidden">
                      <Image
                        src={`/${s.image}`}
                        alt={s.imageCaption}
                        fill
                        className="riso object-cover"
                      />
                    </div>
                    <figcaption className="mono text-[11.5px] leading-5 text-ink-soft p-3 border-t border-ink/15">
                      {s.imageCaption}
                    </figcaption>
                  </figure>

                  <div className="panel p-6 border-l-[3px] border-l-stamp">
                    <p className="mono-label text-stamp">{s.caseTitle}</p>
                    <p className="mt-3 text-[15px] leading-[1.65]">{s.caseIntro}</p>
                    <ol className="mt-4 mono text-[12px] leading-6 border-t border-ink/20 pt-4 space-y-2">
                      {s.caseSteps.map((step, i) => (
                        <li key={i} className="flex gap-3">
                          <span className="text-stamp shrink-0">
                            {String(i + 1).padStart(2, "0")}
                          </span>
                          <span className="min-w-0 break-words">{step}</span>
                        </li>
                      ))}
                    </ol>
                    <p className="mt-4 text-[14px] italic text-ink/80 border-t border-ink/20 pt-4">
                      {s.caseNote}
                    </p>
                  </div>
                </aside>
              </div>
            </article>
          ))}

          {/* Diagram alur — digambar sebagai SVG */}
          <section id="diagram-alur" className="scroll-mt-32">
            <p className="mono-label text-stamp">Lampiran · Simbol Diagram Alur</p>
            <h2 className="display text-[36px] mt-3">
              Satu keputusan, dua kemungkinan hasil
            </h2>
            <p className="mt-4 measure text-[16px] text-ink/80">
              Diagram berikut adalah gambaran algoritma pada Bab 05. Persegi untuk proses, belah
              ketupat untuk keputusan, panah untuk arah aliran, dan oval untuk awal–akhir.
            </p>
            <div className="mt-8 panel p-6 sm:p-10 overflow-x-auto">
              <div className="min-w-[640px]">
                <FlowchartKetuntasan />
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
