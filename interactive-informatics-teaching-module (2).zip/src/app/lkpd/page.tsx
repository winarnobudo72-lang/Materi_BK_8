import { CommentBox, LkpdClient } from "@/components/LkpdClient";
import { getContent, listComments } from "@/lib/repo";

export const dynamic = "force-dynamic";

const fmt = (d: Date) =>
  new Intl.DateTimeFormat("id-ID", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Jakarta",
  }).format(d);

export default async function LkpdPage() {
  const { lkpd, meta } = await getContent();
  const comments = (await listComments()).slice(0, 4);

  return (
    <div className="mx-auto max-w-[1240px] px-5">
      <header className="pt-12 pb-10 border-b-[3px] border-ink grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px] items-end">
        <div>
          <p className="mono-label text-stamp">
            LKPD · {meta.material} · {meta.phase}
          </p>
          <h1 className="display text-[clamp(38px,6vw,68px)] mt-3">
            Lembar Kerja Peserta Didik
          </h1>
          <p className="mt-5 measure text-[16.5px] text-ink/85">{lkpd.intro}</p>
        </div>
        <div className="panel p-5 mono text-[12px] leading-6">
          <p className="mono-label text-ink-soft">Petunjuk Umum</p>
          <p className="mt-3">1. Isi nama dan kelas dengan benar.</p>
          <p>2. Kerjakan {lkpd.tasks.length} aktivitas secara berurutan.</p>
          <p>3. Gunakan kalimatmu sendiri, boleh mencontoh kasus di sekitarmu.</p>
          <p>4. Tekan “Kumpulkan” bila seluruh jawaban sudah selesai.</p>
        </div>
      </header>

      <div className="py-12">
        <LkpdClient tasks={lkpd.tasks} />
      </div>

      <div className="pb-16 grid gap-12 lg:grid-cols-[minmax(0,62ch)_minmax(0,1fr)]">
        <CommentBox />
        <aside className="lg:sticky lg:top-32 self-start">
          <p className="mono-label text-ink-soft">Komentar Terakhir Siswa</p>
          <div className="mt-4 space-y-4">
            {comments.length === 0 && (
              <p className="mono text-[12px] text-ink-soft border border-ink/25 p-5">
                Belum ada komentar. Jadilah yang pertama menulis kesan.
              </p>
            )}
            {comments.map((c) => (
              <article key={c.id} className="panel p-5 border-l-[3px] border-l-stamp">
                <p className="text-[15px]">{c.message}</p>
                <p className="mono text-[11px] text-ink-soft mt-3">
                  {c.studentName} · {c.className} · {fmt(c.createdAt)}
                </p>
              </article>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
}
