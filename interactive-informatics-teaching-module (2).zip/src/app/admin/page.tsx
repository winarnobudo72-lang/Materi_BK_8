import AdminClient, { LoginAdmin } from "@/components/AdminClient";
import { isAuthenticated } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const authed = await isAuthenticated();
  return authed ? <AdminClient /> : <LoginAdmin />;
}
