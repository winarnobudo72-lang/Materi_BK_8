"use client";

import { useEffect, useState } from "react";

const HARI = [
  "Minggu",
  "Senin",
  "Selasa",
  "Rabu",
  "Kamis",
  "Jumat",
  "Sabtu",
];
const BULAN = [
  "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember",
];

function pad(n: number) {
  return String(n).padStart(2, "0");
}

/** Jam waktu-nyata gaya stempel absensi guru. */
export default function Clock({ compact = false }: { compact?: boolean }) {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  const wib = now
    ? new Date(now.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }))
    : null;

  const dateLine = wib
    ? `${HARI[wib.getDay()]}, ${wib.getDate()} ${BULAN[wib.getMonth()]} ${wib.getFullYear()}`
    : "Memuat tanggal…";
  const timeLine = wib ? `${pad(wib.getHours())}:${pad(wib.getMinutes())}:${pad(wib.getSeconds())}` : "--:--:--";

  if (compact) {
    return (
      <span className="mono text-[12px] tracking-[0.12em] whitespace-nowrap">
        <span className="hidden sm:inline">{dateLine} · </span>
        <span className="text-stamp">{timeLine}</span> WIB
      </span>
    );
  }

  return (
    <div className="flex items-stretch gap-0 border border-ink/30 bg-paper-2/70">
      <div className="flex flex-col justify-center px-4 py-3 border-r border-ink/20">
        <span className="mono-label text-ink-soft">Waktu nyata · WIB</span>
        <span className="mono text-[13px] mt-1">{dateLine}</span>
      </div>
      <div className="flex items-center px-5 bg-ink text-paper">
        <span className="mono text-[26px] sm:text-[32px] leading-none tracking-[0.04em] tabular-nums">
          {timeLine}
        </span>
      </div>
    </div>
  );
}
