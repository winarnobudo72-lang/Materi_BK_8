"use client";

import { useState } from "react";
import { KELAS_LIST, type LkpdTask } from "@/lib/types";

function KelasSelect({
  value,
  onChange,
  id,
}: {
  value: string;
  onChange: (v: string) => void;
  id: string;
}) {
  return (
    <select
      id={id}
      className="field mono"
      required
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">— Pilih kelas —</option>
      {KELAS_LIST.map((k) => (
        <option key={k} value={k}>
          {k}
        </option>
      ))}
    </select>
  );
}

export function LkpdClient({ tasks }: { tasks: LkpdTask[] }) {
  const [studentName, setStudentName] = useState("");
  const [className, setClassName] = useState("");
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [receipt, setReceipt] = useState<{ id?: number; waktu: string } | null>(null);

  const answered = Object.values(answers).filter((v) => v.trim()).length;
  const totalQ = tasks.reduce((n, t) => n + t.questions.length, 0);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("sending");
    const payload: Record<string, Record<string, string>> = {};
    tasks.forEach((t) => {
      payload[t.id] = {};
      t.questions.forEach((q) => {
        payload[t.id][q.id] = answers[q.id] ?? "";
      });
    });
    try {
      const res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "lkpd",
          studentName,
          className,
          answers: payload,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? "Gagal menyimpan.");
      setReceipt({
        id: data.id,
        waktu: new Intl.DateTimeFormat("id-ID", {
          dateStyle: "full",
          timeStyle: "long",
          timeZone: "Asia/Jakarta",
        }).format(new Date()),
      });
      setState("done");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Terjadi kesalahan jaringan.");
      setState("error");
    }
  }

  if (state === "done" && receipt) {
    return (
      <div className="panel p-8 sm:p-12 border-l-[3px] border-l-moss">
        <p className="mono-label text-moss">Jawaban LKPD Tersimpan</p>
        <h3 className="display text-[36px] mt-3">Terima kasih, {studentName}!</h3>
        <dl className="mt-6 mono text-[13px] leading-7">
          <div className="flex gap-4 border-b border-ink/15 py-1">
            <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
              Nama Siswa
            </dt>
            <dd>{studentName}</dd>
          </div>
          <div className="flex gap-4 border-b border-ink/15 py-1">
            <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
              Kelas
            </dt>
            <dd>{className}</dd>
          </div>
          <div className="flex gap-4 border-b border-ink/15 py-1">
            <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
              Jumlah Jawaban
            </dt>
            <dd>
              {answered} dari {totalQ} pertanyaan
            </dd>
          </div>
          <div className="flex gap-4 py-1">
            <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
              Waktu Pengumpulan
            </dt>
            <dd>{receipt.waktu}</dd>
          </div>
        </dl>
        <p className="mt-6 text-[15px] text-ink/80 measure">
          Identitas dan jawabanmu telah tersimpan pada basis data sekolah dan dapat dilihat oleh
          Budi Winarno, S.Kom melalui halaman admin.
        </p>
        <button type="button" className="btn btn-ghost mt-6" onClick={() => window.print()}>
          Cetak / Simpan PDF
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-10">
      <div className="panel p-7">
        <p className="mono-label text-stamp">Identitas Peserta Didik</p>
        <div className="mt-5 grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="lkpd-nama" className="mono-label text-ink-soft block mb-2">
              Nama Siswa
            </label>
            <input
              id="lkpd-nama"
              className="field"
              required
              maxLength={80}
              placeholder="Tulis nama lengkapmu"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="lkpd-kelas" className="mono-label text-ink-soft block mb-2">
              Kelas
            </label>
            <KelasSelect id="lkpd-kelas" value={className} onChange={setClassName} />
          </div>
        </div>
        <p className="mono text-[11.5px] text-ink-soft mt-4">
          Identitas ini akan disimpan bersama seluruh jawaban LKPD.
        </p>
      </div>

      {tasks.map((task) => (
        <section key={task.id} className="border-t-[3px] border-ink pt-6">
          <p className="mono-label text-stamp">{task.step}</p>
          <h3 className="display text-[28px] mt-2">{task.activity}</h3>
          <p className="mt-3 measure text-[15.5px] text-ink/85">{task.instruction}</p>

          <div className="mt-6 space-y-7">
            {task.questions.map((q, i) => (
              <div key={q.id}>
                <label htmlFor={q.id} className="block text-[15.5px] font-semibold">
                  {i + 1}. {q.text}
                </label>
                <textarea
                  id={q.id}
                  className="field ruled mt-2"
                  style={{ minHeight: q.lines * 28 }}
                  placeholder="Tulis jawabanmu di sini…"
                  value={answers[q.id] ?? ""}
                  onChange={(e) =>
                    setAnswers((prev) => ({ ...prev, [q.id]: e.target.value }))
                  }
                />
              </div>
            ))}
          </div>
        </section>
      ))}

      {state === "error" && (
        <p className="mono text-[13px] text-stamp border border-stamp p-4">{message}</p>
      )}

      <div className="flex flex-wrap items-center gap-5 border-t-[3px] border-ink pt-6">
        <button type="submit" className="btn" disabled={state === "sending"}>
          {state === "sending" ? "Menyimpan…" : "Kumpulkan Jawaban LKPD"}
        </button>
        <p className="mono text-[12px] text-ink-soft">
          Terisi {answered} / {totalQ} pertanyaan
        </p>
      </div>
    </form>
  );
}

export function CommentBox() {
  const [studentName, setStudentName] = useState("");
  const [className, setClassName] = useState("");
  const [message, setMessage] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [note, setNote] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "comment", studentName, className, message }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? "Gagal menyimpan komentar.");
      setState("done");
      setMessage("");
    } catch (err) {
      setNote(err instanceof Error ? err.message : "Terjadi kesalahan jaringan.");
      setState("error");
    }
  }

  return (
    <section id="komentar" className="scroll-mt-32">
      <div className="rule-thick mb-6" />
      <p className="mono-label text-stamp">Kolom Komentar Siswa</p>
      <h3 className="display text-[32px] mt-2">Apa kesanmu tentang modul ini?</h3>
      <p className="mt-3 measure text-[15.5px] text-ink/80">
        Tulis pendapat, kesulitan, atau usulanmu. Komentar akan dibaca langsung oleh guru
        pengampu.
      </p>

      {state === "done" ? (
        <div className="panel p-6 mt-6 border-l-[3px] border-l-moss">
          <p className="mono-label text-moss">Komentar Terkirim</p>
          <p className="mt-3 text-[15.5px]">
            Terima kasih, {studentName || "siswa"}! Komentarmu sudah masuk ke kolom guru.
          </p>
          <button
            type="button"
            className="btn btn-ghost mt-5"
            onClick={() => {
              setState("idle");
              setStudentName("");
              setClassName("");
            }}
          >
            Tulis komentar lain
          </button>
        </div>
      ) : (
        <form onSubmit={submit} className="mt-6 grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="komentar-nama" className="mono-label text-ink-soft block mb-2">
              Nama Siswa
            </label>
            <input
              id="komentar-nama"
              className="field"
              required
              maxLength={80}
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="komentar-kelas" className="mono-label text-ink-soft block mb-2">
              Kelas
            </label>
            <KelasSelect id="komentar-kelas" value={className} onChange={setClassName} />
          </div>
          <div className="sm:col-span-2">
            <label htmlFor="komentar-isi" className="mono-label text-ink-soft block mb-2">
              Komentar
            </label>
            <textarea
              id="komentar-isi"
              className="field"
              style={{ minHeight: 120 }}
              required
              maxLength={800}
              placeholder="Tulis komentarmu di sini…"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
          </div>
          {state === "error" && (
            <p className="sm:col-span-2 mono text-[13px] text-stamp border border-stamp p-3">
              {note}
            </p>
          )}
          <div className="sm:col-span-2">
            <button type="submit" className="btn" disabled={state === "sending"}>
              {state === "sending" ? "Mengirim…" : "Kirim Komentar"}
            </button>
          </div>
        </form>
      )}
    </section>
  );
}
