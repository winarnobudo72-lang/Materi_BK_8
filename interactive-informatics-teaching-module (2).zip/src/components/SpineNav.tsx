"use client";

import { useEffect, useState } from "react";

type Item = { id: string; no: string; title: string };

export default function SpineNav({ items }: { items: Item[] }) {
  const [active, setActive] = useState(items[0]?.id ?? "");

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
        if (visible) setActive(visible.target.id);
      },
      { rootMargin: "-25% 0px -60% 0px", threshold: 0.01 },
    );
    items.forEach((item) => {
      const el = document.getElementById(item.id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [items]);

  return (
    <nav aria-label="Daftar bab" className="lg:sticky lg:top-32">
      <p className="mono-label text-ink-soft mb-5">Pita Modul</p>
      <ul className="space-y-7">
        {items.map((item) => (
          <li key={item.id} className="spine-node" data-active={active === item.id}>
            <a href={`#${item.id}`} className="block group">
              <span className="mono text-[11px] text-stamp tracking-[0.18em]">BAB {item.no}</span>
              <span
                className={`block text-[14px] leading-snug mt-1 transition-colors ${
                  active === item.id ? "text-ink font-semibold" : "text-ink/70"
                } group-hover:text-stamp`}
              >
                {item.title}
              </span>
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
