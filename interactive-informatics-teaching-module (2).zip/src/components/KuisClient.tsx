"use client";

import { useMemo, useState } from "react";
import { KELAS_LIST } from "@/lib/types";

export type PublicQuestion = {
  id: string;
  topic: string;
  question: string;
  options: string[];
};

type Detail = {
  id: string;
  question: string;
  picked: string;
  correctText: string;
  correct: boolean;
};

type Result = {
  score: number;
  correct: number;
  total: number;
  detail: Detail[];
  studentName: string;
  className: string;
  waktu: string;
};

export default function KuisClient({
  questions,
  intro,
}: {
  questions: PublicQuestion[];
  intro: string;
}) {
  const [phase, setPhase] = useState<"identity" | "exam" | "result">("identity");
  const [studentName, setStudentName] = useState("");
  const [className, setClassName] = useState("");
  const [picks, setPicks] = useState<Record<string, string>>({});
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);

  const answered = useMemo(
    () => questions.filter((q) => picks[q.id]).length,
    [picks, questions],
  );

  async function submit() {
    setSending(true);
    setError("");
    try {
      const rows = questions
        .filter((q) => picks[q.id])
        .map((q) => ({ id: q.id, picked: picks[q.id] }));
      const res = await fetch("/api/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "quiz",
          studentName,
          className,
          answers: rows,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? "Gagal menyimpan nilai.");
      setResult({
        score: data.score,
        correct: data.correct,
        total: data.total,
        detail: data.detail,
        studentName,
        className,
        waktu: new Intl.DateTimeFormat("id-ID", {
          dateStyle: "full",
          timeStyle: "long",
          timeZone: "Asia/Jakarta",
        }).format(new Date()),
      });
      setPhase("result");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan jaringan.");
    } finally {
      setSending(false);
    }
  }

  if (phase === "identity") {
    return (
      <div className="grid gap-10 lg:grid-cols-[minmax(0,62ch)_minmax(0,1fr)]">
        <form
          className="panel p-8"
          onSubmit={(e) => {
            e.preventDefault();
            setPhase("exam");
            window.scrollTo({ top: 0, behavior: "smooth" });
          }}
        >
          <p className="mono-label text-stamp">Identitas Peserta Didik</p>
          <h2 className="display text-[32px] mt-3">Siapkan identitasmu</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <div>
              <label htmlFor="kuis-nama" className="mono-label text-ink-soft block mb-2">
                Nama Siswa
              </label>
              <input
                id="kuis-nama"
                className="field"
                required
                maxLength={80}
                placeholder="Tulis nama lengkapmu"
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
              />
            </div>
            <div>
              <label htmlFor="kuis-kelas" className="mono-label text-ink-soft block mb-2">
                Kelas
              </label>
              <select
                id="kuis-kelas"
                className="field mono"
                required
                value={className}
                onChange={(e) => setClassName(e.target.value)}
              >
                <option value="">— Pilih kelas —</option>
                {KELAS_LIST.map((k) => (
                  <option key={k} value={k}>
                    {k}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <p className="mono text-[11.5px] text-ink-soft mt-4">
            Nama dan kelas akan tersimpan bersama nilai kuis pada basis data sekolah.
          </p>
          <button type="submit" className="btn mt-6">
            Mulai Kuis →
          </button>
        </form>

        <aside className="panel p-8 border-l-[3px] border-l-stamp">
          <p className="mono-label text-stamp">Aturan Main</p>
          <ul className="mt-4 mono text-[12.5px] leading-7">
            <li>01 — Bank soal berisi 25 soal.</li>
            <li>02 — Kamu mengerjakan 20 soal acak.</li>
            <li>03 — Urutan soal DAN pilihan jawaban diacak.</li>
            <li>04 — Setiap soal bernilai 5 poin (skor 0–100).</li>
            <li>05 — Nilai tersimpan setelah tombol kumpulkan ditekan.</li>
          </ul>
          <p className="mt-5 text-[14.5px] text-ink/80">{intro}</p>
        </aside>
      </div>
    );
  }

  if (phase === "result" && result) {
    const predicate = result.score >= 75;
    return (
      <div className="space-y-12">
        <div className="grid gap-8 lg:grid-cols-[320px_minmax(0,1fr)] items-start">
          <div className="panel-ink p-8">
            <p className="mono-label text-paper/70">Nilai Kuis</p>
            <p
              className="display text-[92px] leading-none mt-2"
              style={{ color: predicate ? "#8FD1A8" : "#F0A08C" }}
            >
              {result.score}
            </p>
            <p className="mono text-[12.5px] mt-4 leading-7">
              {result.correct} benar dari {result.total} soal
              <br />
              KKM mata pelajaran: 75
              <br />
              {result.waktu}
            </p>
          </div>
          <div className="panel p-8 border-l-[3px] border-l-stamp">
            <p className="mono-label text-stamp">Rincian Hasil</p>
            <h2 className="display text-[34px] mt-3">
              {predicate ? "Tuntas, bagus!" : "Belum tuntas, ayo ulangi!"}
            </h2>
            <dl className="mt-5 mono text-[13px] leading-7">
              <div className="flex gap-4 border-b border-ink/15 py-1">
                <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
                  Nama Siswa
                </dt>
                <dd>{result.studentName}</dd>
              </div>
              <div className="flex gap-4 border-b border-ink/15 py-1">
                <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
                  Kelas
                </dt>
                <dd>{result.className}</dd>
              </div>
              <div className="flex gap-4 py-1">
                <dt className="w-[150px] text-ink-soft uppercase tracking-[0.12em] text-[10.5px] pt-1">
                  Status
                </dt>
                <dd style={{ color: predicate ? "#3F6B52" : "#D8452A" }}>
                  {predicate ? "TUNTAS" : "REMEDIAL"}
                </dd>
              </div>
            </dl>
            <p className="mt-5 text-[15px] text-ink/80">
              Nilai ini sudah tersimpan pada basis data sekolah lengkap dengan nama dan kelas.
            </p>
            <div className="flex flex-wrap gap-3 mt-6">
              <button type="button" className="btn" onClick={() => window.print()}>
                Cetak Hasil
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => window.location.reload()}
              >
                Kerjakan Ulang
              </button>
            </div>
          </div>
        </div>

        <section>
          <p className="mono-label text-stamp">Pembahasan Jawaban</p>
          <div className="mt-5 border-t-[3px] border-ink">
            {result.detail.map((d, i) => (
              <div key={d.id} className="py-5 border-b border-ink/15">
                <div className="flex gap-4">
                  <span className="mono text-[12px] text-ink-soft shrink-0">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[15.5px] font-semibold">{d.question}</p>
                    <p className="mono text-[12.5px] mt-2">
                      <span className={d.correct ? "text-moss" : "text-stamp"}>
                        {d.correct ? "✓ BENAR" : "✗ SALAH"}
                      </span>
                      {" — jawabanmu: "}
                      {d.picked || "(tidak dijawab)"}
                    </p>
                    {!d.correct && (
                      <p className="mono text-[12.5px] text-moss mt-1">
                        Kunci: {d.correctText}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    );
  }

  return (
    <div>
      <div className="sticky top-[100px] z-30 panel px-5 py-3 flex flex-wrap items-center gap-4">
        <p className="mono text-[12px]">
          {studentName} · <span className="text-stamp">{className}</span>
        </p>
        <p className="mono text-[12px] text-ink-soft">
          Terjawab {answered} / {questions.length}
        </p>
        <div className="h-[3px] flex-1 min-w-[100px] bg-ink/15">
          <div
            className="h-full bg-stamp transition-[width] duration-200"
            style={{ width: `${(answered / questions.length) * 100}%` }}
          />
        </div>
        <button type="button" className="btn" onClick={submit} disabled={sending}>
          {sending ? "Menyimpan…" : "Kumpulkan Nilai"}
        </button>
      </div>

      {error && (
        <p className="mono text-[13px] text-stamp border border-stamp p-4 mt-6">{error}</p>
      )}

      <ol className="mt-10 space-y-10">
        {questions.map((q, i) => (
          <li key={q.id} className="border-t-[3px] border-ink pt-5">
            <div className="flex flex-wrap gap-3 items-baseline">
              <span className="mono text-[12px] text-stamp">
                Soal {String(i + 1).padStart(2, "0")}
              </span>
              <span className="mono-label text-ink-soft">{q.topic}</span>
            </div>
            <p className="mt-3 text-[16.5px] font-semibold measure">{q.question}</p>
            <div className="mt-4 grid gap-2 sm:grid-cols-2">
              {q.options.map((opt, oi) => {
                const checked = picks[q.id] === opt;
                return (
                  <label
                    key={oi}
                    className={`flex gap-3 items-start border px-4 py-3 cursor-pointer transition-colors ${
                      checked
                        ? "border-stamp bg-stamp/10"
                        : "border-ink/20 hover:border-ink/50"
                    }`}
                  >
                    <input
                      type="radio"
                      name={q.id}
                      className="mt-1 accent-[#D8452A]"
                      checked={checked}
                      onChange={() => setPicks((p) => ({ ...p, [q.id]: opt }))}
                    />
                    <span className="text-[15px] leading-snug">
                      <span className="mono text-[11px] text-ink-soft mr-2">
                        {String.fromCharCode(65 + oi)}.
                      </span>
                      {opt}
                    </span>
                  </label>
                );
              })}
            </div>
          </li>
        ))}
      </ol>

      <div className="mt-12 border-t-[3px] border-ink pt-6 flex flex-wrap items-center gap-5">
        <button type="button" className="btn" onClick={submit} disabled={sending}>
          {sending ? "Menyimpan…" : "Kumpulkan Nilai"}
        </button>
        <p className="mono text-[12px] text-ink-soft">
          Pastikan seluruh jawaban sudah terisi. Nilai tersimpan bersama nama dan kelas.
        </p>
      </div>
    </div>
  );
}
