/** Diagram alur menghitung ketuntasan nilai — digambar tangan sebagai SVG. */
export function FlowchartKetuntasan({ id = "fc" }: { id?: string }) {
  return (
    <svg
      viewBox="0 0 720 300"
      className="w-full h-auto draw-in"
      role="img"
      aria-label="Diagram alur menentukan ketuntasan nilai siswa"
    >
      <defs>
        <marker
          id={`${id}-arrow`}
          viewBox="0 0 10 10"
          refX="8"
          refY="5"
          markerWidth="7"
          markerHeight="7"
          orient="auto-start-reverse"
        >
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#15263F" />
        </marker>
      </defs>

      {/* MULAI */}
      <ellipse cx="90" cy="46" rx="62" ry="24" fill="#E8DFC9" stroke="#15263F" strokeWidth="2" />
      <text x="90" y="51" textAnchor="middle" className="mono" fontSize="13" fill="#15263F">
        MULAI
      </text>

      <path d="M 90 70 L 90 100" stroke="#15263F" strokeWidth="2" markerEnd={`url(#${id}-arrow)`} />

      {/* BACA himpunan data */}
      <path
        d="M 55 100 L 118 100 L 133 132 L 40 132 Z"
        fill="#F2ECDE"
        stroke="#15263F"
        strokeWidth="2"
      />
      <text x="88" y="121" textAnchor="middle" className="mono" fontSize="11.5" fill="#15263F">
        BACA himpunan data nilai
      </text>

      <path d="M 88 132 L 88 158" stroke="#15263F" strokeWidth="2" markerEnd={`url(#${id}-arrow)`} />

      {/* ULANGI setiap baris */}
      <rect x="8" y="158" width="160" height="42" fill="#E8DFC9" stroke="#15263F" strokeWidth="2" />
      <text x="88" y="184" textAnchor="middle" className="mono" fontSize="11.5" fill="#15263F">
        ULANGI tiap baris
      </text>

      <path d="M 88 200 L 88 226" stroke="#15263F" strokeWidth="2" markerEnd={`url(#${id}-arrow)`} />

      {/* JIKA nilai < 75 */}
      <path
        d="M 88 226 L 178 262 L 88 298 L -2 262 Z"
        fill="#F2ECDE"
        stroke="#15263F"
        strokeWidth="2"
      />
      <text x="88" y="260" textAnchor="middle" className="mono" fontSize="12" fill="#15263F">
        JIKA nilai &lt; 75
      </text>
      <text x="88" y="276" textAnchor="middle" className="mono" fontSize="12" fill="#15263F">
        MAKA?
      </text>

      {/* cabang YA */}
      <path
        d="M 178 262 L 300 262 L 300 120"
        stroke="#D8452A"
        strokeWidth="2"
        fill="none"
        markerEnd={`url(#${id}-arrow)`}
      />
      <text x="196" y="252" className="mono" fontSize="11" fill="#D8452A">
        BENAR
      </text>
      <rect x="222" y="120" width="156" height="42" fill="#D8452A" stroke="#15263F" strokeWidth="2" />
      <text x="300" y="146" textAnchor="middle" className="mono" fontSize="11.5" fill="#F2ECDE">
        TULIS “Remedial”
      </text>

      {/* cabang TIDAK */}
      <path
        d="M -2 262 L -2 288"
        stroke="#15263F"
        strokeWidth="2"
        fill="none"
        markerEnd={`url(#${id}-arrow)`}
        transform="translate(2,0)"
      />
      <path
        d="M 88 298 L 88 288 L 470 288 L 470 210"
        stroke="#15263F"
        strokeWidth="2"
        fill="none"
        markerEnd={`url(#${id}-arrow)`}
      />
      <text x="104" y="315" className="mono" fontSize="11" fill="#15263F">
        SALAH → SELAINYA
      </text>
      <rect x="392" y="168" width="156" height="42" fill="#E8DFC9" stroke="#15263F" strokeWidth="2" />
      <text x="470" y="194" textAnchor="middle" className="mono" fontSize="11.5" fill="#15263F">
        TULIS “Tuntas”
      </text>

      {/* hasil keputusan kembali ke perulangan */}
      <path
        d="M 300 120 L 300 92 L 640 92 L 640 262 L 586 262"
        stroke="#3F6B52"
        strokeWidth="2"
        fill="none"
        markerEnd={`url(#${id}-arrow)`}
      />
      <text x="330" y="84" className="mono" fontSize="11" fill="#3F6B52">
        kembali ke baris berikutnya
      </text>

      {/* SELESAI */}
      <ellipse cx="548" cy="262" rx="62" ry="24" fill="#15263F" stroke="#15263F" strokeWidth="2" />
      <text x="548" y="267" textAnchor="middle" className="mono" fontSize="13" fill="#F2ECDE">
        SELESAI
      </text>
    </svg>
  );
}

/** Pita alur tujuan pembelajaran: empat elemen berpikir komputasional. */
export function FlowRibbon() {
  const steps = [
    { n: "01", t: "Dekomposisi", d: "Pecah masalah" },
    { n: "02", t: "Pola", d: "Cari keteraturan" },
    { n: "03", t: "Abstraksi", d: "Ambil yang penting" },
    { n: "04", t: "Algoritma", d: "Susun langkah" },
  ];
  return (
    <svg viewBox="0 0 980 132" className="w-full h-auto draw-in" role="img" aria-label="Alur empat elemen berpikir komputasional">
      {steps.map((s, i) => {
        const x = 24 + i * 240;
        return (
          <g key={s.n}>
            <rect x={x} y="26" width="196" height="80" fill="#E8DFC9" stroke="#15263F" strokeWidth="2" />
            <text x={x + 16} y="52" className="mono" fontSize="12" letterSpacing="2" fill="#D8452A">
              {s.n}
            </text>
            <text x={x + 16} y="76" fontSize="21" fontFamily="Fraunces, serif" fontWeight="600" fill="#15263F">
              {s.t}
            </text>
            <text x={x + 16} y="95" className="mono" fontSize="11" fill="#6B6353">
              {s.d}
            </text>
            {i < steps.length - 1 && (
              <path
                d={`M ${x + 196} 66 L ${x + 232} 66`}
                stroke="#15263F"
                strokeWidth="2"
                markerEnd="url(#ribbon-arrow)"
              />
            )}
          </g>
        );
      })}
      <defs>
        <marker id="ribbon-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
          <path d="M 0 0 L 10 5 L 0 10 z" fill="#15263F" />
        </marker>
      </defs>
    </svg>
  );
}
