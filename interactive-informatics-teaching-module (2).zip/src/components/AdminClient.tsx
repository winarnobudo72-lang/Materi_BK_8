"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { ModuleContent, QuizQuestion } from "@/lib/types";

/* ——————————————————————————— Login ——————————————————————————— */

export function LoginAdmin() {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", user, pass }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.message ?? "Login gagal.");
      window.location.reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan.");
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-16 grid gap-12 lg:grid-cols-[minmax(0,460px)_minmax(0,1fr)] items-start">
      <form onSubmit={submit} className="panel p-8">
        <p className="mono-label text-stamp">Masuk Area Guru</p>
        <h1 className="display text-[34px] mt-3">Login Admin</h1>
        <p className="mt-3 text-[15px] text-ink/80">
          Halaman ini khusus untuk guru pengampu. Melalui panel admin, isi modul dapat diubah dan
          seluruh data siswa dapat dilihat serta diunduh.
        </p>
        <div className="mt-6 space-y-5">
          <div>
            <label htmlFor="adm-user" className="mono-label text-ink-soft block mb-2">
              Nama Pengguna
            </label>
            <input
              id="adm-user"
              className="field mono"
              autoComplete="username"
              required
              value={user}
              onChange={(e) => setUser(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="adm-pass" className="mono-label text-ink-soft block mb-2">
              Kata Sandi
            </label>
            <input
              id="adm-pass"
              type="password"
              className="field mono"
              autoComplete="current-password"
              required
              value={pass}
              onChange={(e) => setPass(e.target.value)}
            />
          </div>
        </div>
        {error && (
          <p className="mono text-[12.5px] text-stamp border border-stamp p-3 mt-5">{error}</p>
        )}
        <button type="submit" className="btn mt-6" disabled={busy}>
          {busy ? "Memeriksa…" : "Masuk →"}
        </button>
      </form>

      <aside className="panel p-8 border-l-[3px] border-l-stamp">
        <p className="mono-label text-stamp">Kewenangan Admin</p>
        <ul className="mt-4 mono text-[12.5px] leading-7">
          <li>01 — Mengubah teks materi, contoh kasus, dan ilustrasi.</li>
          <li>02 — Mengubah isi slide presentasi beserta catatan guru.</li>
          <li>03 — Mengubah instruksi dan pertanyaan LKPD.</li>
          <li>04 — Menambah, mengubah, dan menghapus bank soal kuis.</li>
          <li>05 — Melihat dan mengunduh nilai kuis (Nama – Kelas – Nilai – Waktu).</li>
          <li>06 — Melihat dan mengunduh jawaban LKPD serta komentar siswa.</li>
        </ul>
        <p className="mt-5 text-[14.5px] text-ink/80">
          Kata sandi diatur melalui variabel lingkungan <span className="mono">ADMIN_USER</span> dan{" "}
          <span className="mono">ADMIN_PASS</span>.
        </p>
      </aside>
    </div>
  );
}

/* ——————————————————————————— Editor generik ——————————————————————————— */

type FieldSpec = {
  key: string;
  label: string;
  type: "text" | "area" | "list" | "pairs" | "qtext" | "select" | "number";
  options?: string[];
  full?: boolean;
};

type Row = Record<string, unknown>;

function encode(item: Row, specs: FieldSpec[]): Record<string, string> {
  const flat: Record<string, string> = {};
  for (const s of specs) {
    const v = item[s.key];
    if (s.type === "list" && Array.isArray(v)) flat[s.key] = (v as string[]).join("\n");
    else if (s.type === "pairs" && Array.isArray(v))
      flat[s.key] = (v as { label: string; text: string }[])
        .map((p) => `${p.label} :: ${p.text}`)
        .join("\n");
    else if (s.type === "qtext" && Array.isArray(v))
      flat[s.key] = (v as { text: string; lines: number }[])
        .map((q) => `${q.text} :: ${q.lines}`)
        .join("\n");
    else flat[s.key] = String(v ?? "");
  }
  return flat;
}

function decode(flat: Record<string, string>, specs: FieldSpec[], base: Row): Row {
  const out: Row = { ...base };
  for (const s of specs) {
    const raw = flat[s.key] ?? "";
    if (s.type === "list") {
      out[s.key] = raw
        .split("\n")
        .map((x) => x.trim())
        .filter(Boolean);
    } else if (s.type === "pairs") {
      out[s.key] = raw
        .split("\n")
        .map((x) => x.trim())
        .filter(Boolean)
        .map((line) => {
          const [label, ...rest] = line.split("::");
          return { label: label.trim(), text: (rest.join("::") || "").trim() };
        });
    } else if (s.type === "qtext") {
      const prev = (base[s.key] as { id: string }[] | undefined) ?? [];
      out[s.key] = raw
        .split("\n")
        .map((x) => x.trim())
        .filter(Boolean)
        .map((line, i) => {
          const [text, ...rest] = line.split("::");
          const lines = Number((rest.join("::") || "").trim());
          return {
            id: prev[i]?.id ?? `${String(base.id ?? "q")}-${s.key}-${i + 1}`,
            text: text.trim(),
            lines: Number.isFinite(lines) && lines > 0 ? lines : 3,
          };
        });
    } else if (s.type === "number") {
      out[s.key] = Number(raw);
    } else {
      out[s.key] = raw;
    }
  }
  return out;
}

function EditList({
  items,
  specs,
  onChange,
  itemTitle,
  makeNew,
}: {
  items: Row[];
  specs: FieldSpec[];
  onChange: (next: Row[]) => void;
  itemTitle: (item: Row, index: number) => string;
  makeNew: (index: number) => Row;
}) {
  const [open, setOpen] = useState<number | null>(0);
  const flats = useMemo(() => items.map((it) => encode(it, specs)), [items, specs]);

  const update = (index: number, key: string, value: string) => {
    const nextFlat = { ...flats[index], [key]: value };
    const next = [...items];
    next[index] = decode(nextFlat, specs, items[index]);
    onChange(next);
  };

  const move = (index: number, delta: number) => {
    const target = index + delta;
    if (target < 0 || target >= items.length) return;
    const next = [...items];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
    setOpen(target);
  };

  return (
    <div className="space-y-3">
      {items.map((item, index) => (
        <div key={index} className="border border-ink/25 bg-paper">
          <div className="flex items-center gap-3 px-4 py-3 border-b border-ink/15">
            <button
              type="button"
              className="mono text-[11px] text-stamp"
              onClick={() => setOpen(open === index ? null : index)}
            >
              {open === index ? "[ − ]" : "[ + ]"}
            </button>
            <p className="text-[15px] font-semibold flex-1 min-w-0 truncate">
              {itemTitle(item, index)}
            </p>
            <button type="button" className="mono text-[11px]" onClick={() => move(index, -1)}>
              ↑
            </button>
            <button type="button" className="mono text-[11px]" onClick={() => move(index, 1)}>
              ↓
            </button>
            <button
              type="button"
              className="mono text-[11px] text-stamp"
              onClick={() => onChange(items.filter((_, i) => i !== index))}
            >
              Hapus
            </button>
          </div>
          {open === index && (
            <div className="p-4 grid gap-4 md:grid-cols-2">
              {specs.map((s) => (
                <div key={s.key} className={s.full ? "md:col-span-2" : ""}>
                  <label className="mono-label text-ink-soft block mb-2">{s.label}</label>
                  {s.type === "select" ? (
                    <select
                      className="field mono"
                      value={flats[index][s.key] ?? ""}
                      onChange={(e) => update(index, s.key, e.target.value)}
                    >
                      {s.options?.map((o) => (
                        <option key={o} value={o}>
                          {o}
                        </option>
                      ))}
                    </select>
                  ) : s.type === "text" ? (
                    <input
                      className="field"
                      value={flats[index][s.key] ?? ""}
                      onChange={(e) => update(index, s.key, e.target.value)}
                    />
                  ) : (
                    <textarea
                      className={`field ${s.type === "list" || s.type === "pairs" || s.type === "qtext" ? "mono text-[12.5px]" : ""}`}
                      rows={
                        s.type === "area"
                          ? 3
                          : Math.max(2, (flats[index][s.key] ?? "").split("\n").length)
                      }
                      value={flats[index][s.key] ?? ""}
                      onChange={(e) => update(index, s.key, e.target.value)}
                    />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}
      <button
        type="button"
        className="btn btn-ghost"
        onClick={() => {
          onChange([...items, makeNew(items.length)]);
          setOpen(items.length);
        }}
      >
        + Tambah Entri
      </button>
    </div>
  );
}

const SECTION_SPECS: FieldSpec[] = [
  { key: "id", label: "ID (tautan #anchor)", type: "text" },
  { key: "no", label: "Nomor Bab", type: "text" },
  { key: "kicker", label: "Label Mono", type: "text", full: true },
  { key: "title", label: "Judul Bab", type: "text", full: true },
  { key: "lead", label: "Kalimat Pembuka", type: "area", full: true },
  { key: "body", label: "Paragraf (satu paragraf per baris)", type: "list", full: true },
  { key: "points", label: "Poin (label :: keterangan)", type: "pairs", full: true },
  { key: "image", label: "Berkas Gambar", type: "text" },
  { key: "imageCaption", label: "Keterangan Gambar", type: "area" },
  { key: "caseTitle", label: "Judul Contoh Kasus", type: "text", full: true },
  { key: "caseIntro", label: "Uraian Contoh Kasus", type: "area", full: true },
  { key: "caseSteps", label: "Langkah Contoh Kasus (per baris)", type: "list", full: true },
  { key: "caseNote", label: "Catatan Penutup", type: "area", full: true },
];

const SLIDE_SPECS: FieldSpec[] = [
  { key: "id", label: "ID Slide", type: "text" },
  { key: "kicker", label: "Label Mono", type: "text" },
  { key: "title", label: "Judul Slide", type: "text", full: true },
  { key: "lead", label: "Kalimat Pembuka", type: "area", full: true },
  { key: "bullets", label: "Butir (per baris)", type: "list", full: true },
  { key: "note", label: "Catatan Guru", type: "area", full: true },
  {
    key: "variant",
    label: "Varian",
    type: "select",
    options: ["cover", "bullets", "case", "recap"],
  },
];

const TASK_SPECS: FieldSpec[] = [
  { key: "id", label: "ID Aktivitas", type: "text" },
  { key: "step", label: "Label Aktivitas", type: "text" },
  { key: "activity", label: "Judul Aktivitas", type: "text", full: true },
  { key: "instruction", label: "Instruksi", type: "area", full: true },
  { key: "questions", label: "Pertanyaan (teks :: jumlah baris)", type: "qtext", full: true },
];

const QUESTION_SPECS: FieldSpec[] = [
  { key: "id", label: "ID Soal", type: "text" },
  { key: "topic", label: "Topik", type: "text" },
  { key: "question", label: "Pertanyaan", type: "area", full: true },
  { key: "options", label: "Pilihan Jawaban (4 baris)", type: "list", full: true },
  {
    key: "answer",
    label: "Kunci (0 = A, 1 = B, 2 = C, 3 = D)",
    type: "select",
    options: ["0", "1", "2", "3"],
  },
  { key: "explanation", label: "Pembahasan", type: "area", full: true },
];

const META_SPECS: FieldSpec[] = [
  { key: "school", label: "Sekolah", type: "text" },
  { key: "phase", label: "Fase / Kelas", type: "text" },
  { key: "teacher", label: "Guru", type: "text" },
  { key: "subject", label: "Mata Pelajaran", type: "text" },
  { key: "material", label: "Materi", type: "text" },
  { key: "time", label: "Alokasi Waktu", type: "text" },
  { key: "title", label: "Judul Modul", type: "text", full: true },
  { key: "subtitle", label: "Sub Judul", type: "area", full: true },
  { key: "capaian", label: "Capaian Pembelajaran", type: "area", full: true },
  { key: "tujuan", label: "Tujuan Pembelajaran", type: "area", full: true },
  { key: "atp", label: "Alur Tujuan Pembelajaran", type: "area", full: true },
  { key: "profilPelajar", label: "Dimensi Profil Pelajar", type: "area", full: true },
];

/* ——————————————————————————— Panel utama ——————————————————————————— */

type Tab = "nilai" | "lkpd" | "komentar" | "konten" | "soal";

const TABS: { id: Tab; label: string }[] = [
  { id: "nilai", label: "Hasil Kuis" },
  { id: "lkpd", label: "Jawaban LKPD" },
  { id: "komentar", label: "Komentar Siswa" },
  { id: "konten", label: "Edit Isi Modul" },
  { id: "soal", label: "Bank Soal" },
];

function fmt(date: string) {
  return new Intl.DateTimeFormat("id-ID", {
    dateStyle: "medium",
    timeStyle: "medium",
    timeZone: "Asia/Jakarta",
  }).format(new Date(date));
}

type QuizRow = {
  id: number;
  studentName: string;
  className: string;
  score: number;
  correct: number;
  total: number;
  createdAt: string;
};
type LkpdRow = {
  id: number;
  studentName: string;
  className: string;
  answers: Record<string, Record<string, string>>;
  createdAt: string;
};
type CommentRow = {
  id: number;
  studentName: string;
  className: string;
  message: string;
  createdAt: string;
};

export default function AdminClient() {
  const [tab, setTab] = useState<Tab>("nilai");
  const [quiz, setQuiz] = useState<QuizRow[]>([]);
  const [lkpd, setLkpd] = useState<LkpdRow[]>([]);
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [content, setContent] = useState<ModuleContent | null>(null);
  const [notice, setNotice] = useState("");
  const [query, setQuery] = useState("");

  const load = useCallback(async () => {
    const res = await fetch("/api/admin");
    if (!res.ok) {
      window.location.reload();
      return;
    }
    const data = await res.json();
    setQuiz(data.quiz ?? []);
    setLkpd(data.lkpd ?? []);
    setComments(data.comments ?? []);
    setContent(data.content ?? null);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function logout() {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "logout" }),
    });
    window.location.reload();
  }

  async function saveKey(key: string, value: unknown) {
    setNotice("Menyimpan…");
    const res = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, value }),
    });
    setNotice(res.ok ? "Perubahan tersimpan." : "Gagal menyimpan perubahan.");
  }

  const rata = quiz.length
    ? Math.round(quiz.reduce((n, r) => n + r.score, 0) / quiz.length)
    : 0;
  const tuntas = quiz.filter((r) => r.score >= 75).length;

  const filteredQuiz = quiz.filter((r) =>
    `${r.studentName} ${r.className}`.toLowerCase().includes(query.toLowerCase()),
  );

  if (!content) {
    return (
      <div className="mx-auto max-w-[1240px] px-5 py-24">
        <p className="mono text-[13px] text-ink-soft">Memuat data admin…</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1240px] px-5 py-10">
      <header className="flex flex-wrap items-end justify-between gap-5 border-b-[3px] border-ink pb-6">
        <div>
          <p className="mono-label text-stamp">Panel Guru · Budi Winarno, S.Kom</p>
          <h1 className="display text-[44px] mt-2">Admin Modul Ajar</h1>
        </div>
        <div className="flex gap-3">
          <a className="btn btn-ghost" href="/api/admin/export?type=quiz">
            Unduh Nilai CSV
          </a>
          <button type="button" className="btn" onClick={logout}>
            Keluar
          </button>
        </div>
      </header>

      <nav className="flex flex-wrap gap-2 mt-6">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={`mono-label px-4 py-2.5 border transition-colors ${
              tab === t.id
                ? "bg-ink text-paper border-ink"
                : "border-ink/30 text-ink hover:border-ink"
            }`}
          >
            {t.label}
          </button>
        ))}
      </nav>

      {notice && (
        <p className="mono text-[12.5px] text-moss border border-moss p-3 mt-5">{notice}</p>
      )}

      {/* ——— Nilai ——— */}
      {tab === "nilai" && (
        <section className="mt-8">
          <div className="grid gap-4 sm:grid-cols-3 mb-6">
            {[
              { label: "Jumlah Peserta", value: String(quiz.length) },
              { label: "Rata-rata Nilai", value: String(rata) },
              { label: "Tuntas (≥ 75)", value: `${tuntas} siswa` },
            ].map((s) => (
              <div key={s.label} className="panel p-5">
                <p className="mono-label text-ink-soft">{s.label}</p>
                <p className="display text-[40px] mt-1">{s.value}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-4 mb-4">
            <input
              className="field max-w-[280px]"
              placeholder="Cari nama atau kelas…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <a className="btn btn-ghost" href="/api/admin/export?type=quiz">
              Unduh Nilai (CSV)
            </a>
            <p className="mono text-[12px] text-ink-soft">
              Nama – Kelas – Nilai – Waktu
            </p>
          </div>

          <div className="overflow-x-auto border border-ink/25">
            <table className="data-table min-w-[720px]">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Siswa</th>
                  <th>Kelas</th>
                  <th>Nilai</th>
                  <th>Benar</th>
                  <th>Keterangan</th>
                  <th>Waktu</th>
                </tr>
              </thead>
              <tbody>
                {filteredQuiz.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-ink-soft">
                      Belum ada data hasil kuis.
                    </td>
                  </tr>
                )}
                {filteredQuiz.map((r, i) => (
                  <tr key={r.id}>
                    <td>{filteredQuiz.length - i}</td>
                    <td className="font-semibold">{r.studentName}</td>
                    <td>{r.className}</td>
                    <td>
                      <span
                        className="px-2 py-0.5 border"
                        style={{
                          color: r.score >= 75 ? "#3F6B52" : "#D8452A",
                          borderColor: r.score >= 75 ? "#3F6B52" : "#D8452A",
                        }}
                      >
                        {r.score}
                      </span>
                    </td>
                    <td>
                      {r.correct}/{r.total}
                    </td>
                    <td>{r.score >= 75 ? "Tuntas" : "Remedial"}</td>
                    <td>{fmt(r.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* ——— LKPD ——— */}
      {tab === "lkpd" && (
        <section className="mt-8">
          <div className="flex flex-wrap items-center gap-4 mb-5">
            <p className="mono text-[12px] text-ink-soft">
              {lkpd.length} berkas jawaban LKPD tersimpan
            </p>
            <a className="btn btn-ghost" href="/api/admin/export?type=lkpd">
              Unduh Jawaban (CSV)
            </a>
          </div>
          <div className="space-y-4">
            {lkpd.length === 0 && (
              <p className="mono text-[13px] text-ink-soft border border-ink/25 p-8 text-center">
                Belum ada jawaban LKPD yang dikumpulkan.
              </p>
            )}
            {lkpd.map((row) => (
              <details key={row.id} className="panel p-5">
                <summary className="cursor-pointer flex flex-wrap items-center gap-4">
                  <span className="text-[16px] font-semibold">{row.studentName}</span>
                  <span className="mono text-[12px] text-stamp">{row.className}</span>
                  <span className="mono text-[12px] text-ink-soft">{fmt(row.createdAt)}</span>
                  <span className="mono text-[11px] text-ink-soft ml-auto">
                    klik untuk membuka jawaban
                  </span>
                </summary>
                <div className="mt-5 space-y-4 border-t border-ink/20 pt-4">
                  {Object.entries(row.answers ?? {}).map(([taskId, qs]) => (
                    <div key={taskId}>
                      <p className="mono-label text-stamp">{taskId}</p>
                      {Object.entries(qs).map(([qid, text]) => (
                        <p key={qid} className="text-[14.5px] mt-2 whitespace-pre-wrap">
                          <span className="mono text-[11px] text-ink-soft mr-2">{qid}</span>
                          {text || "—"}
                        </p>
                      ))}
                    </div>
                  ))}
                </div>
              </details>
            ))}
          </div>
        </section>
      )}

      {/* ——— Komentar ——— */}
      {tab === "komentar" && (
        <section className="mt-8">
          <div className="flex flex-wrap items-center gap-4 mb-5">
            <p className="mono text-[12px] text-ink-soft">{comments.length} komentar siswa</p>
            <a className="btn btn-ghost" href="/api/admin/export?type=comments">
              Unduh Komentar (CSV)
            </a>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {comments.length === 0 && (
              <p className="mono text-[13px] text-ink-soft border border-ink/25 p-8 text-center md:col-span-2">
                Belum ada komentar siswa.
              </p>
            )}
            {comments.map((c) => (
              <article key={c.id} className="panel p-5 border-l-[3px] border-l-stamp">
                <p className="text-[15px]">{c.message}</p>
                <p className="mono text-[11.5px] text-ink-soft mt-4">
                  {c.studentName} · {c.className} · {fmt(c.createdAt)}
                </p>
              </article>
            ))}
          </div>
        </section>
      )}

      {/* ——— Edit isi modul ——— */}
      {tab === "konten" && (
        <section className="mt-8 space-y-12">
          <div>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="display text-[28px]">Identitas & Tujuan Modul</h2>
              <button
                type="button"
                className="btn"
                onClick={() => saveKey("meta", decode(encode(content.meta, META_SPECS), META_SPECS, {}))}
              >
                Simpan Identitas
              </button>
            </div>
            <div className="mt-5 panel p-5 grid gap-4 md:grid-cols-2">
              {META_SPECS.map((s) => (
                <div key={s.key} className={s.full ? "md:col-span-2" : ""}>
                  <label className="mono-label text-ink-soft block mb-2">{s.label}</label>
                  {s.type === "text" ? (
                    <input
                      className="field"
                      value={String(content.meta[s.key as keyof typeof content.meta] ?? "")}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          meta: { ...content.meta, [s.key]: e.target.value },
                        })
                      }
                    />
                  ) : (
                    <textarea
                      className="field"
                      rows={3}
                      value={String(content.meta[s.key as keyof typeof content.meta] ?? "")}
                      onChange={(e) =>
                        setContent({
                          ...content,
                          meta: { ...content.meta, [s.key]: e.target.value },
                        })
                      }
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="display text-[28px]">Materi (Bab)</h2>
              <button type="button" className="btn" onClick={() => saveKey("sections", content.sections)}>
                Simpan Materi
              </button>
            </div>
            <div className="mt-5">
              <EditList
                items={content.sections as unknown as Row[]}
                specs={SECTION_SPECS}
                onChange={(next) =>
                  setContent({ ...content, sections: next as unknown as ModuleContent["sections"] })
                }
                itemTitle={(item, i) => `${String(item.no ?? i + 1).padStart(2, "0")} · ${String(item.title ?? "")}`}
                makeNew={(i) => ({
                  id: `bab-${i + 1}`,
                  no: String(i + 1).padStart(2, "0"),
                  kicker: "Bab Baru",
                  title: "Judul bab baru",
                  lead: "",
                  body: [""],
                  points: [{ label: "", text: "" }],
                  image: "images/bab-data.jpg",
                  imageCaption: "",
                  caseTitle: "Contoh Kasus",
                  caseIntro: "",
                  caseSteps: [""],
                  caseNote: "",
                })}
              />
            </div>
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="display text-[28px]">Slide Presentasi</h2>
              <button type="button" className="btn" onClick={() => saveKey("slides", content.slides)}>
                Simpan Slide
              </button>
            </div>
            <div className="mt-5">
              <EditList
                items={content.slides as unknown as Row[]}
                specs={SLIDE_SPECS}
                onChange={(next) =>
                  setContent({ ...content, slides: next as unknown as ModuleContent["slides"] })
                }
                itemTitle={(item, i) => `${String(i + 1).padStart(2, "0")} · ${String(item.title ?? "")}`}
                makeNew={(i) => ({
                  id: `s${i + 1}`,
                  kicker: `Slide ${String(i + 1).padStart(2, "0")}`,
                  title: "Judul slide baru",
                  lead: "",
                  bullets: [""],
                  note: "",
                  variant: "bullets",
                })}
              />
            </div>
          </div>

          <div>
            <div className="flex flex-wrap items-center justify-between gap-4">
              <h2 className="display text-[28px]">LKPD</h2>
              <button type="button" className="btn" onClick={() => saveKey("lkpd", content.lkpd)}>
                Simpan LKPD
              </button>
            </div>
            <label className="mono-label text-ink-soft block mb-2 mt-5">Petunjuk LKPD</label>
            <textarea
              className="field"
              rows={3}
              value={content.lkpd.intro}
              onChange={(e) =>
                setContent({ ...content, lkpd: { ...content.lkpd, intro: e.target.value } })
              }
            />
            <div className="mt-5">
              <EditList
                items={content.lkpd.tasks as unknown as Row[]}
                specs={TASK_SPECS}
                onChange={(next) =>
                  setContent({
                    ...content,
                    lkpd: { ...content.lkpd, tasks: next as unknown as ModuleContent["lkpd"]["tasks"] },
                  })
                }
                itemTitle={(item, i) => `${String(item.step ?? i + 1)} · ${String(item.activity ?? "")}`}
                makeNew={(i) => ({
                  id: `t${i + 1}`,
                  step: `Aktivitas ${i + 1}`,
                  activity: "Aktivitas baru",
                  instruction: "",
                  questions: [{ id: `t${i + 1}q1`, text: "", lines: 3 }],
                })}
              />
            </div>
          </div>
        </section>
      )}

      {/* ——— Bank soal ——— */}
      {tab === "soal" && (
        <section className="mt-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="display text-[28px]">Bank Soal Kuis</h2>
              <p className="mono text-[12px] text-ink-soft mt-1">
                {content.quiz.questions.length} soal tersimpan · sistem mengambil 20 soal acak
              </p>
            </div>
            <button
              type="button"
              className="btn"
              onClick={() =>
                saveKey("quiz", {
                  intro: content.quiz.intro,
                  questions: content.quiz.questions.map((q) => ({
                    ...q,
                    answer: Number(q.answer),
                  })),
                })
              }
            >
              Simpan Bank Soal
            </button>
          </div>
          <label className="mono-label text-ink-soft block mb-2 mt-5">Petunjuk Kuis</label>
          <textarea
            className="field"
            rows={2}
            value={content.quiz.intro}
            onChange={(e) =>
              setContent({ ...content, quiz: { ...content.quiz, intro: e.target.value } })
            }
          />
          <div className="mt-6">
            <EditList
              items={content.quiz.questions as unknown as Row[]}
              specs={QUESTION_SPECS}
              onChange={(next) =>
                setContent({
                  ...content,
                  quiz: { ...content.quiz, questions: next as unknown as QuizQuestion[] },
                })
              }
              itemTitle={(item, i) =>
                `${String(item.id ?? i + 1)} · ${String(item.topic ?? "")} — ${String(item.question ?? "").slice(0, 60)}`
              }
              makeNew={(i) => ({
                id: `q${String(i + 1).padStart(2, "0")}`,
                topic: "Topik",
                question: "Tulis pertanyaan…",
                options: ["Pilihan A", "Pilihan B", "Pilihan C", "Pilihan D"],
                answer: 0,
                explanation: "",
              })}
            />
          </div>
        </section>
      )}
    </div>
  );
}
