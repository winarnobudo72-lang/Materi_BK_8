"use client";

import { useCallback, useEffect, useState } from "react";
import type { Slide } from "@/lib/types";

export default function Slides({ slides }: { slides: Slide[] }) {
  const [index, setIndex] = useState(0);
  const [dir, setDir] = useState(1);

  const go = useCallback(
    (next: number) => {
      const clamped = Math.max(0, Math.min(slides.length - 1, next));
      setDir(clamped >= index ? 1 : -1);
      setIndex(clamped);
    },
    [index, slides.length],
  );

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "PageDown") go(index + 1);
      if (e.key === "ArrowLeft" || e.key === "PageUp") go(index - 1);
      if (e.key === "Home") go(0);
      if (e.key === "End") go(slides.length - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, index, slides.length]);

  const slide = slides[index];
  const progress = ((index + 1) / slides.length) * 100;

  return (
    <div>
      {/* Panggung proyeksi */}
      <div className="bg-ink py-8 sm:py-12 border-b-[3px] border-ink">
        <div className="mx-auto max-w-[1240px] px-5">
          <div
            key={slide.id}
            className="relative bg-paper border border-paper/25 shadow-[8px_8px_0_rgba(0,0,0,0.35)] overflow-hidden fade-up"
            style={{ animationName: "fadeUp", animationDuration: "260ms" }}
          >
            <div
              className="absolute inset-y-0 left-0 w-[10px]"
              style={{
                background:
                  slide.variant === "cover"
                    ? "#D8452A"
                    : slide.variant === "recap"
                      ? "#3F6B52"
                      : "#15263F",
              }}
            />
            <div
              className="pl-10 sm:pl-16 pr-6 sm:pr-14 py-10 sm:py-16 min-h-[420px] sm:min-h-[520px] flex flex-col justify-center"
              style={{
                transform: `translateX(${dir > 0 ? "0" : "0"})`,
              }}
            >
              <p className="mono-label text-stamp">{slide.kicker}</p>
              <h2
                className={`display mt-4 ${
                  slide.variant === "cover"
                    ? "text-[clamp(40px,7vw,86px)] max-w-[14ch]"
                    : "text-[clamp(30px,4.4vw,58px)] max-w-[20ch]"
                }`}
              >
                {slide.title}
              </h2>
              <p className="mt-5 font-display italic text-[clamp(16px,2vw,24px)] text-ink/80 max-w-[46ch]">
                {slide.lead}
              </p>
              <ul className="mt-8 space-y-3 max-w-[62ch]">
                {slide.bullets.map((b, i) => (
                  <li key={i} className="flex gap-4 items-baseline">
                    <span className="mono text-[11px] text-stamp shrink-0">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-[clamp(15px,1.6vw,19px)] leading-[1.55]">{b}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Kendali */}
          <div className="mt-6 flex flex-wrap items-center gap-4 text-paper">
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => go(index - 1)}
                disabled={index === 0}
                className="btn bg-paper text-ink border-paper disabled:opacity-35 hover:bg-stamp hover:text-paper"
                aria-label="Slide sebelumnya"
              >
                ← Sebelumnya
              </button>
              <button
                type="button"
                onClick={() => go(index + 1)}
                disabled={index === slides.length - 1}
                className="btn bg-paper text-ink border-paper disabled:opacity-35 hover:bg-stamp hover:text-paper"
                aria-label="Slide berikutnya"
              >
                Berikutnya →
              </button>
            </div>
            <p className="mono text-[12px] tabular-nums">
              {String(index + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}
            </p>
            <div className="h-[3px] flex-1 min-w-[120px] bg-paper/25">
              <div
                className="h-full bg-stamp transition-[width] duration-200"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mono text-[11px] text-paper/60">
              Tekan ← → pada papan ketik
            </p>
          </div>
        </div>
      </div>

      {/* Catatan guru + daftar slide */}
      <div className="mx-auto max-w-[1240px] px-5 py-12 grid gap-10 lg:grid-cols-[minmax(0,62ch)_minmax(0,1fr)]">
        <div className="panel p-7 border-l-[3px] border-l-stamp">
          <p className="mono-label text-stamp">Catatan Guru · Slide {index + 1}</p>
          <p className="mt-4 text-[16.5px] leading-[1.7]">{slide.note}</p>
        </div>
        <div>
          <p className="mono-label text-ink-soft">Daftar Slide</p>
          <ul className="mt-4 border-t-[3px] border-ink">
            {slides.map((s, i) => (
              <li key={s.id}>
                <button
                  type="button"
                  onClick={() => go(i)}
                  className={`w-full text-left grid grid-cols-[38px_minmax(0,1fr)] gap-3 py-3 border-b border-ink/15 transition-colors ${
                    i === index ? "bg-paper-2/80" : "hover:bg-paper-2/50"
                  }`}
                >
                  <span
                    className={`mono text-[12px] ${i === index ? "text-stamp" : "text-ink-soft"}`}
                  >
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-[14.5px] leading-snug">{s.title}</span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
