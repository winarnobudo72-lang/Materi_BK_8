import Link from "next/link";
import Clock from "./Clock";

const NAV = [
  { href: "/", label: "Beranda" },
  { href: "/materi", label: "Materi" },
  { href: "/slides", label: "Slide" },
  { href: "/lkpd", label: "LKPD" },
  { href: "/kuis", label: "Kuis" },
  { href: "/admin", label: "Admin" },
];

export function Mark({ size = 34 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      aria-hidden="true"
      className="shrink-0"
    >
      <rect x="2.5" y="2.5" width="43" height="43" rx="2" stroke="currentColor" strokeWidth="1.6" />
      <path
        d="M24 8.5 L36 20 L24 31.5 L12 20 Z"
        stroke="currentColor"
        strokeWidth="1.6"
        fill="none"
      />
      <path d="M24 31.5 L24 39.5" stroke="currentColor" strokeWidth="1.6" />
      <rect x="18.5" y="35" width="11" height="6" stroke="currentColor" strokeWidth="1.6" fill="none" />
      <path d="M17.5 20 L21 23.4 L27.5 15.6" stroke="#D8452A" strokeWidth="2.2" fill="none" />
    </svg>
  );
}

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40">
      <div className="bg-ink text-paper/85">
        <div className="mx-auto max-w-[1240px] px-5 h-8 flex items-center justify-between">
          <p className="mono-label truncate">
            SMP Negeri 2 Ngadirejo · Fase D / Kelas VIII · Guru: Budi Winarno, S.Kom
          </p>
          <div className="mono-label text-paper/70">
            <Clock compact />
          </div>
        </div>
      </div>
      <div className="bg-paper/95 backdrop-blur-[2px] border-b-[3px] border-ink">
        <div className="mx-auto max-w-[1240px] px-5 h-16 flex items-center justify-between gap-6">
          <Link href="/" className="flex items-center gap-3 text-ink min-w-0">
            <Mark />
            <span className="min-w-0">
              <span className="block display text-[19px] leading-none truncate">
                Berpikir Komputasional
              </span>
              <span className="block mono-label text-ink-soft mt-1">
                Modul Ajar Interaktif · Informatika
              </span>
            </span>
          </Link>
          <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="mono-label px-2.5 py-2 text-ink hover:text-stamp transition-colors whitespace-nowrap"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t-[3px] border-ink bg-paper-2/60">
      <div className="mx-auto max-w-[1240px] px-5 py-10 grid gap-6 md:grid-cols-[1fr_auto] items-end">
        <div>
          <p className="mono-label text-ink-soft">Lembar Kerja Digital · Tahun Pelajaran 2025/2026</p>
          <p className="display text-[28px] mt-2">SMP Negeri 2 Ngadirejo</p>
          <p className="text-sm text-ink-soft mt-2 measure">
            Modul Ajar Informatika Fase D — Elemen Berpikir Komputasional. Disusun untuk
            kegiatan belajar mengajar kelas VIII, terdiri atas materi, slide presentasi,
            LKPD, kuis, dan kolom komentar siswa.
          </p>
        </div>
        <div className="mono text-[12px] text-ink-soft leading-6 md:text-right">
          <p>Guru Pengampu: Budi Winarno, S.Kom</p>
          <p>Alokasi waktu: 4 × 40 menit (2 pertemuan)</p>
          <p className="text-stamp">Data nilai tersimpan di basis data sekolah</p>
        </div>
      </div>
    </footer>
  );
}
