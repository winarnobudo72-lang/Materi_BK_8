import {
  integer,
  jsonb,
  serial,
  text,
  timestamp,
  pgTable,
} from "drizzle-orm/pg-core";

/** Penyimpanan isi modul yang bisa diedit admin (per kunci: meta, sections, slides, lkpd, quiz). */
export const moduleContent = pgTable("module_content", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Hasil kuis: identitas siswa + nilai tersimpan. */
export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  className: text("class_name").notNull(),
  score: integer("score").notNull(),
  correct: integer("correct").notNull(),
  total: integer("total").notNull(),
  answers: jsonb("answers").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Jawaban LKPD: identitas siswa tersimpan bersama jawaban. */
export const lkpdSubmissions = pgTable("lkpd_submissions", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  className: text("class_name").notNull(),
  answers: jsonb("answers").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

/** Kolom komentar siswa. */
export const studentComments = pgTable("student_comments", {
  id: serial("id").primaryKey(),
  studentName: text("student_name").notNull(),
  className: text("class_name").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});
